# 烘干机 PC 仿真 UI 功能交接文档

> **主源文件**：`src/ui/ui-烘干硬件.c`
> **文档目录**：`src/ui/`
> **更新日期**：2026-06-11
> **适用工程**：`lv_port_pc_vscode-master`（CMake `USE_UI_HW=ON`）

---

## 1. 概述

本次在烘干机硬件 UI 源文件（`ui-烘干硬件.c`）上新增并完善了以下能力，用于 PC 端 LVGL 仿真验证完整业务流程：

| 模块 | 说明 |
|------|------|
| **追加时间页** | 主页启停后，有追加能力的程序先进入追加时间选择，再进支付 |
| **管理员程序设置** | 扩展 5 个程序的金额、烘干、追加、温度等参数（表 3.1 初值） |
| **会话机制** | 追加次数确定后锁定金额/总时长/运行分段，供支付页与运行页使用 |
| **状态栏时钟同步** | 管理员页、追加时间页顶栏时钟与主页共用 `cb_clock()` 定时刷新 |
| **追加页操作简化** | 移除底部「取消/确认」，改由顶栏「返回/启停」承担原逻辑 |

---

## 2. 编译与源文件关系

### 2.1 CMake 开关

```cmake
option(USE_UI_HW "Build hardware FSM UI (ui-烘干硬件.c) for PC simulator" ON)
```

- **`USE_UI_HW=ON`（默认）**：将 `src/ui/ui-烘干硬件.c` **复制**为 `build/ui_hw_sim.c` 参与编译，并链接 `src/ui/pc_sim/task_fsm_pc.c`、`init_pc.c`。
- **`USE_UI_HW=OFF`**：编译通用演示 UI `src/ui/ui.c`。

> **注意**：修改 `ui-烘干硬件.c` 后需重新 **Configure/Build**，CMake 才会把最新内容复制到 `build/ui_hw_sim.c`。

### 2.2 PC 仿真 FSM

硬件 FSM 状态机在 `src/ui/pc_sim/task_fsm_pc.c` 中桩实现；UI 通过 `fsm.state`、`SETFLAG`/`GETFLAG`、`ui_scr_load_async()` 与屏幕切换联动。

---

## 3. 用户流程（主页 → 追加 → 支付 → 运行）

```mermaid
flowchart TD
    A[主页 g_scr_home] -->|启停/居中卡片| B{有追加能力?}
    B -->|否 如风自洁| C[add_time_session_commit 0]
    C --> D[SETFLAG NEED_PAYMENT]
    D --> E[ui_scr_load_async → 支付页]
    B -->|是| F[追加时间页 g_scr_add_time]
    F -->|顶栏 返回| A
    F -->|顶栏 启停| G[add_time_session_commit]
    G --> D
    E --> H[支付完成页 2s 自动]
    H --> I[运行页 g_scr_running]
```

### 3.1 入口：`ui_fsm_runpause_apply()`（约 2270 行）

主页 `FSM_STANDBY` 且当前屏为 `g_scr_home` 时：

- **`add_time_max_count(g_wheel_sel) == 0`**（风自洁等无追加）：`commit(0)` → `SETFLAG(FSM_FLAG_NEED_PAYMENT)` → 异步进支付页。
- **有追加能力**：`g_add_time_sel = 0`，刷新追加页标签，`ui_screen_load(g_scr_add_time)`；**不**置 `NEED_PAYMENT`，FSM 保持 `STANDBY`。

原「直达支付」代码以注释保留在 `ui_fsm_runpause_apply()` 内，便于对照。

### 3.2 支付页 → 运行页

- `state_to_scr(FSM_STANDBY)` 根据 `FSM_FLAG_NEED_PAYMENT` / `FSM_FLAG_PAYMENT_SUCCESS` 选择支付页或支付完成页。
- 支付完成页 `pay_done_timer_start()`：2 秒后 `fsm_state_change(FSM_RUNNING)` 并加载运行页。

---

## 4. 追加时间页（`g_scr_add_time`）

### 4.1 构建函数

- **`build_add_time()`**（约 7373 行）：在 `ui_init()` 中调用。
- 编码器组：**`g_group_add_time`**，焦点顺序由 **`add_time_encoder_group_build()`** 重建。

### 4.2 界面结构

| 区域 | 内容 |
|------|------|
| 顶栏 | 返回图标、启停、电源、4G/WiFi/时钟 |
| 中间栏 1600×400 | 标题、程序名（`s_font_sc_50`）、总金额/总时间/追加次数三列 |
| 次数列下方 | 橙色「上」「下」按钮，步进追加次数 |

**已移除**：底部「取消」「确认」按钮。

### 4.3 顶栏按钮逻辑

| 按钮 | 回调 | 行为 |
|------|------|------|
| 返回 | `cb_add_time_back` | `add_time_session_clear()` → 回主页 |
| 启停 | `cb_add_time_runpause` | `add_time_session_commit(g_add_time_sel)` → `SETFLAG(NEED_PAYMENT)` → `ui_scr_load_async()` |
| 电源 | `cb_add_time_power_stub` | 空桩，待硬件对接 |

### 4.4 计算规则

| 函数 | 公式 |
|------|------|
| `add_time_calc_price` | 程序金额 + 追加金额 × 选定次数 |
| `add_time_calc_total_sec` | 初始烘干 + 次数×追加时间 + 冷却 |
| `add_time_max_count` | 取程序设置 `add_count`；无 `PROG_CAP_ADD_COUNT/ADD_TIME` 时返回 0 |

PC 演示下 `PROG_ADMIN_DEMO_SEC=1`，时间字段按**秒**存储与显示（如 `20s`）。

### 4.5 会话变量（确定后生效）

```c
g_add_time_sel          // 追加页当前选择 0..add_count
g_session_add_count     // 确定后的追加次数 → param_change[2]
g_session_total_price     // 支付页金额
g_session_total_sec       // 运行页总倒计时
g_session_run_stages      // 运行页阶段条（烘干+冷却分段）
g_session_active          // 是否已 commit
```

- **`add_time_session_commit(sel)`**：写入上述会话字段。
- **`add_time_session_clear()`**：离开追加页回主页、运行结束等场景清除。

### 4.6 与支付/运行的衔接

- **支付页进入**（`ui_screen_load` 分支 `g_scr_pay`）：`param_change[2]` 在有会话时取 `g_session_add_count`，否则取程序默认 `add_count`。
- **支付金额**：`pay_sync_price_label()` 优先 `g_session_total_price`。
- **运行倒计时**：`g_running_remain_sec` 优先 `g_session_total_sec`；阶段条优先 `g_session_run_stages`。

### 4.7 屏幕加载钩子

进入 `g_scr_add_time` 时（约 3422 行）：

- 重置 `g_add_time_sel = 0`
- `add_time_page_sync_labels()`
- 切换编码器组，默认焦点在返回键

离开主页进入其他屏时（非追加页）会 `add_time_session_clear()`。

---

## 5. 管理员「程序设置」

### 5.1 数据模型

```c
ui_program_admin_t g_prog_cfg[TOTAL_PROGRAMS];        // 编辑中配置
ui_program_admin_t g_prog_cfg_factory[TOTAL_PROGRAMS];  // 表 3.1 出厂初值
ui_program_profile_t g_program_profiles[];              // 主页底部展示（时间/温度/金额）
ui_program_run_stages_t g_program_run_stages[];       // 运行页基础分段（不含用户追加）
```

能力位 `PROG_CAP_*` 控制各程序可见字段；风自洁使用 `PROG_CAP_AIR_CLEAN`（无追加，追加金额显示 `--`）。

### 5.2 出厂初值（`program_admin_init_factory`，约 4725 行）

| 程序 | 金额 | 追加价 | 初始烘干 | 追加次数×单次 | 温度 | 冷却 |
|------|------|--------|----------|---------------|------|------|
| 低温 | 6 | 1 | 18s | 7×10s | 40℃ | 2s |
| 中温 | 6 | 1 | 18s | 7×10s | 50℃ | 2s |
| 高温 | 6 | 1 | 18s | 7×10s | 60℃ | 2s |
| 冷风 | 6 | 1 | — | 7×10s | — | 10s |
| 风自洁 | 1 | — | — | 无追加 | — | 2s |

### 5.3 主页总时长与追加的关系

- **主页底部时间**（`g_program_profiles[].wash_sec`）= **初始烘干 + 冷却**，由 `program_admin_total_sec()` 计算，**不含**追加×次数。
- **`add_count`** 仅表示追加页可选上限（0~N），不并入主页展示时长。
- 用户选定追加次数后，总时长在追加页实时计算，commit 后写入会话供运行页使用。

### 5.4 确认与同步

- **确认**：`cb_admin_prog_confirm` → `program_admin_ui_save_fields()` → `program_admin_apply_all()` → `home_sync_program_labels()`。
- **`program_admin_apply_one`**：同步 profile、温度文案、运行基础分段到 `g_program_run_stages`（烘干段仍不含用户追加）。

### 5.5 程序设置上栏总时长

`program_admin_update_total_display()` 使用 `program_admin_total_sec(&g_prog_cfg[sel])` 实时计算（初始烘干+冷却）。与主页 `wash_sec` 在**未点确认**前若编辑过字段可能短暂不一致；确认后 `apply_all` 会对齐。

### 5.6 关键 UI 函数索引

| 函数 | 作用 |
|------|------|
| `program_admin_build_panel` | 构建程序设置子面板 |
| `program_admin_ui_load_fields` / `save_fields` | UI ↔ `g_prog_cfg` |
| `program_admin_ui_apply_caps` | 按 cap 显隐字段 |
| `program_admin_sync_prog_pick_ui` | 程序 Tab 选中样式 + 总时长 |
| `cb_admin_prog_pick` / `reset` / `confirm` | 切换程序 / 恢复出厂 / 确认 |

管理员密码：**888888**（`build_admin` 内）。

---

## 6. 状态栏时钟同步

**`cb_clock()`**（约 2400 行）每秒刷新各页顶栏 `HH:MM`：

- 已包含：`g_lbl_clock`（主页）、`g_lbl_clock_running`、`g_lbl_clock_pay`、`g_lbl_clock_admin`、`g_lbl_clock_add_time` 等。
- 仿真起点：`10:08:00`（`s_clock_seconds` 静态计数，24h 回绕）。

`create_top_status_bar()` 在后续页面注册时钟 label 时会调用一次 `cb_clock(NULL)` 做初值对齐。

---

## 7. 支付页启停说明（未单独实现）

支付页 `build_pay()` 中启停绑定的是全局 **`cb_runpause` / `cb_runpause_long`**，最终进入 `ui_fsm_runpause_apply()`。

当前逻辑仅在 **`FSM_STANDBY` 且当前屏为主页** 时才会触发进追加/支付；在支付页上点击启停**通常无页面跳转**。进入支付页时编码器默认焦点在 **返回键** `g_pay_btn_back`，用于避免误触启停。

若需「支付页启停模拟支付完成」，需在 `ui_fsm_runpause_apply()` 中增加 `g_scr_pay` 分支或单独回调。

---

## 8. 关键符号速查

| 符号 | 说明 |
|------|------|
| `g_scr_add_time` | 追加时间屏幕 |
| `g_group_add_time` | 追加页编码器组 |
| `build_add_time` | 构建追加时间页 |
| `add_time_page_sync_labels` | 刷新追加页显示 |
| `add_time_session_commit` / `clear` | 会话提交/清除 |
| `cb_add_time_back` | 返回主页 |
| `cb_add_time_runpause` | 确定并进支付 |
| `g_prog_cfg` | 管理员程序配置 |
| `program_admin_init_factory` | 出厂初值 |
| `PROG_ADMIN_DEMO_SEC` | `1`=秒制演示，`0`=分钟×60 |
| `param_change[]` | 进支付页时写给 MCU/通信的参数数组 |
| `ui_scr_load_async` | 异步按 FSM 切屏 |

---

## 9. 国际化字符串（追加时间相关）

| ID | 中文 |
|----|------|
| `STR_ADD_TIME_TITLE` | 请选择烘干追加时间，默认不追加，直接点击启停即可 |
| `STR_ADD_TIME_TOTAL_PRICE` | 总金额 |
| `STR_ADD_TIME_TOTAL_TIME` | 运行总时间 |
| `STR_ADD_TIME_BTN_UP` / `DOWN` | 上 / 下 |

绑定方式：`ui_lang_bind_label`、`orange_btn_bind_i18n`。

---

## 10. 编码器焦点顺序

### 追加时间页

返回 → 启停 → 电源 → 上 → 下（不首尾循环）

### 主页（参考）

启停 → 电源 → 语言 → 管理员 → 轮播；轮播双击 400ms 内回启停。

---

## 11. 已知事项与后续建议

1. **字体**：追加页部分字符（如「选」「即」「总」「￥」）需确认 `ui_font_SC_30` 字模是否齐全；程序名使用 `s_font_sc_50`。
2. **追加页电源**：`cb_add_time_power_stub` 仍为占位，需对接关机/报警等硬件逻辑。
3. **支付页启停**：见第 7 节，尚未绑定「模拟支付成功」行为。
4. **程序设置入口**：`cb_admin_open_program_settings` 当前默认 `g_admin_prog_sel = 0`（低温）；若需与主页当前程序一致，可改为 `g_wheel_sel`。
5. **编辑未确认**：管理员程序设置编辑中，上栏总时长为实时计算值；主页底部仍为上次 `apply_all` 后的 profile，属预期行为。
6. **硬件移植**：正式板将 `PROG_ADMIN_DEMO_SEC` 置 `0`，时间字段按分钟存储并在 `program_admin_total_sec` 等处 ×60。

---

## 12. 建议自测清单

- [ ] 低温/中温/高温：主页启停 → 追加页 → 上下调次数 → 启停 → 支付页金额/二维码 → 支付完成 → 运行倒计时含追加时长
- [ ] 风自洁：主页启停直达支付（不经过追加页）
- [ ] 追加页返回：会话清除，回主页后支付金额恢复程序默认
- [ ] 管理员程序设置：修改初始烘干/冷却 → 确认 → 主页底部时间更新
- [ ] 管理员/追加页顶栏时钟与主页同步走时
- [ ] 编码器：追加页焦点顺序与返回默认焦点
- [ ] 修改 `ui-烘干硬件.c` 后重新 CMake 构建，`build/ui_hw_sim.c` 已更新

---

## 13. 相关文件一览

```
src/ui/
├── ui-烘干硬件.c          # 主 UI 源文件（本文档描述对象）
├── ui.c                   # USE_UI_HW=OFF 时的通用 UI
├── ui.h
├── fonts/                 # SC_20/30/35/50/125 等
├── image/                 # 程序图、二维码、顶栏图标
└── pc_sim/
    ├── task_fsm_pc.c      # PC FSM 桩
    └── init_pc.c          # PC 初始化

CMakeLists.txt             # USE_UI_HW 与 ui_hw_sim.c 复制规则
```

---

*文档由开发交接整理，如有流程或参数变更，请同步更新本节与 `ui-烘干硬件.c` 内注释。*
