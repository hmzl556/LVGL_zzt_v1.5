如何接入自定义 LVGL 字体

1) 使用 LVGL Font Converter 导出字体，并将生成的 .c 文件放到当前目录。
2) 当前商用洗 UI 使用以下符号名：
   - ui_font_SC_20   启停/电源、4G/时间、童锁
   - ui_font_SC_30   支付页提示文字
   - ui_font_SC_35   主页底部标签、运行页底部文字
   - ui_font_SC_50   程序名、支付完成/洗涤完成标题
   - ui_font_SC_125  运行页倒计时
3) 重新构建项目。

映射见 ui_fonts.c / ui.c 中的 ui_set_obj_font 调用。
