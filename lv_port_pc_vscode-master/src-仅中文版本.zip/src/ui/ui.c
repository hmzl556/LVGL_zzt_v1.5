#include "ui.h"
#include "fonts/ui_fonts.h"
#include <math.h>
#include <stdio.h>
#include <stdint.h>

// #define BEEP_POWER 1
// #define BEEP_EXCEPTION 2
// #define BEEP_CHILD_LOCK_ON 3			√
// #define BEEP_CHECK_AND_FACTORY 4
// #define BEEP_START 5					√
// #define BEEP_PAUSE 6					√
// #define BEEP_END 7					√
// #define BEEP_PROGRAM_CHOOSE 8		√
// #define BEEP_ADDITIONAL_SETTING 9
// #define BEEP_RESERVE 10				√
// #define BEEP_CHILD_LOCK_OFF 11		√


//向蜂鸣器任务发送音效序号（RTOS 队列；PC 仿真为空实现）
static void ui_send_beep_seq(int32_t seq)
{
#if USE_RTOS_FREERTOS
	rtos *app = get_rtos();
	if(app == NULL || app->q_beep == NULL) {
		return;
	}
	BeepReq req = { seq, 0 };
	(void)xQueueSend(app->q_beep, &req, pdMS_TO_TICKS(10));
#else
	(void)seq;
#endif
}

#define UI_FIXED_W          1600u     //屏幕宽度像素
#define UI_FIXED_H          600u      //屏幕高度像素

#define MODE_SCALE_MIN      180       //最小缩放 (180/256倍)
#define MODE_SCALE_MAX      256       //最大缩放 (256/256倍)

#define MODE_IDX_DEFAULT    2         //商用洗默认选中「标准洗」（居中槽位）
#define CAROUSEL_VISIBLE_SLOTS 5      //轮播区同时可见卡片数（其余程序在逻辑环上隐藏）
#define CAROUSEL_CENTER_SLOT   2      //居中选中槽位下标 0..4

#define COL_BG              0x000000  //背景颜色-黑
#define COL_TEXT            0xFFFFFF  //文本颜色-白
#define COL_ORANGE          0xFF8C42  //按钮颜色-橙
#define COL_DIM             0x888888  //非选中状态颜色-灰
#define COL_CHILD_LOCK_RED  0xD03030  //童锁激活：圆形按钮填充色
#define COL_CHILD_LOCK_WHITE 0xF5F5F5 //童锁未激活：白按钮填充色
#define CHILD_LOCK_LONG_PRESS_MS 3000u	//童锁长按 3 秒

/* 商用洗程序总数 */
#define TOTAL_PROGRAMS 5

static lv_group_t* g_ui_group;
static lv_group_t* g_group_off;
static lv_group_t* g_group_home;
static lv_group_t* g_group_running;
static lv_group_t* g_group_end;
static lv_group_t* g_group_pay;
static lv_group_t* g_group_pay_done;

static void ui_set_encoder_group(lv_group_t * group);

static void ui_screen_load(lv_obj_t * scr);

static lv_coord_t s_mode_card_sz;
static lv_coord_t s_mode_step_x;       /* 拖动灵敏度基准（平均槽距） */
static lv_coord_t s_mode_gap_outer;    /* 第1-2、第4-5 之间间距（较窄） */
static lv_coord_t s_mode_gap_inner;    /* 第2-3、第3-4 之间间距（较宽） */
static lv_coord_t s_mode_row_shift_up;
static lv_coord_t s_mode_drag_snap_px;

static lv_obj_t * g_scr_off;
static lv_obj_t * g_scr_home;
static lv_obj_t * g_scr_running;
static lv_obj_t * g_scr_end;
static lv_obj_t * g_scr_pay;
static lv_obj_t * g_scr_pay_done;
static lv_obj_t * g_lbl_clock;
static lv_obj_t * g_lbl_clock_running;
static lv_obj_t * g_lbl_clock_end;
static lv_obj_t * g_lbl_clock_pay;
static lv_obj_t * g_lbl_clock_pay_done;
static lv_obj_t * g_lbl_clock_off;
static lv_obj_t * g_off_btn_power;
static lv_timer_t * g_idle_timer;
static lv_coord_t g_idle_last_ptr_x = -1;
static lv_coord_t g_idle_last_ptr_y = -1;
static lv_obj_t * g_mode_carousel;
static lv_obj_t * g_mode_cards[CAROUSEL_VISIBLE_SLOTS];
static lv_obj_t * g_mode_card_imgs[CAROUSEL_VISIBLE_SLOTS];
static lv_obj_t * g_mode_dots[TOTAL_PROGRAMS];
static lv_obj_t * g_cap_subtitle;
static lv_obj_t * g_lbl_home_time;
static lv_obj_t * g_lbl_home_temp;
static lv_obj_t * g_lbl_home_pay;
static lv_obj_t * g_lbl_pay_price;
static lv_obj_t * g_kuaixi_run_lbl_status;
static lv_obj_t * g_kuaixi_run_lbl_stages;
static lv_obj_t * g_running_mode_label;   /* 运行页中间程序名，与 g_wheel_sel / 轮播一致 */
static lv_obj_t * g_running_time_label; /* 运行页倒计时标签 */
static lv_timer_t * g_running_countdown_timer;
static lv_timer_t * g_running_blink_timer;
static lv_timer_t * g_pay_done_timer;
static uint32_t g_running_remain_sec;
static bool g_running_countdown_paused;
static bool g_running_blink_visible;
static int32_t g_wheel_sel = MODE_IDX_DEFAULT; /* 0..TOTAL_PROGRAMS-1 */
static float g_wheel_turn = 0.f; /* fractional slot offset while dragging */
static lv_coord_t g_wheel_press_x;
static bool g_wheel_dragging;
static bool g_wheel_moved;
/* 运行页童锁 */
static lv_obj_t * g_running_mid;                 /* 中间栏：童锁按钮对齐参考 */
static lv_obj_t * g_running_btn_back;
static lv_obj_t * g_running_btn_runpause;
static lv_obj_t * g_running_btn_power;
static lv_obj_t * g_running_child_lock_btn;
static lv_obj_t * g_running_child_lock_lbl;
static lv_obj_t * g_running_lock_blocker;      /* 全屏遮罩：童锁时拦截触摸 */
static bool g_ui_child_lock;                     /* 童锁激活时拦截主页滑动及除童锁外的界面跳转 */

/* 商用洗程序名，与 g_program_imgs[] 顺序一致 */
static const char * const g_mode_display_names[TOTAL_PROGRAMS] = {
	"大物",
	"单脱水",
	"标准洗",
	"筒自洁",
	"快洗",
};

LV_IMAGE_DECLARE(img_01_dawu);
LV_IMAGE_DECLARE(img_02_dantuoshui);
LV_IMAGE_DECLARE(img_03_biaozhunxi);
LV_IMAGE_DECLARE(img_04_tongzijie);
LV_IMAGE_DECLARE(img_05_kuaixi);

static const lv_image_dsc_t * const g_program_imgs[TOTAL_PROGRAMS] = {
	&img_01_dawu, &img_02_dantuoshui, &img_03_biaozhunxi, &img_04_tongzijie, &img_05_kuaixi
};

/* 程序参数：与 g_mode_display_names[] / g_program_imgs[] 下标一致 */
typedef struct {
	uint32_t wash_sec;
	const char * temp;
	int32_t price;   /* 默认金额；-1 表示无 */
} ui_program_profile_t;

static const ui_program_profile_t g_program_profiles[TOTAL_PROGRAMS] = {
	{ 42, "40℃",  9 },   /* 大物 */
	{  9, "--",    5 },   /* 单脱水 */
	{ 35, "30℃",  8 },   /* 标准洗 */
	{  3, "--",   1 },   /* 筒自洁 */
	{ 24, "COLD",  7 },   /* 快洗 */
};

/* ========== ui.c 功能函数前向声明 ========== */
static void ui_send_beep_seq(int32_t seq);  //向蜂鸣器任务发送音效序号（RTOS 队列；PC 仿真为空实现）
static void ui_apply_chinese_font(void);  //绑定中文字体并应用到 LVGL 默认主题
static lv_obj_t * make_text_btn(lv_obj_t * parent, const char * txt, lv_coord_t w, lv_coord_t h);  //创建透明背景文本按钮
static lv_obj_t * make_orange_fill_btn(lv_obj_t * parent, const char * txt, lv_coord_t w, lv_coord_t h);  //创建橙色实心圆角按钮
static lv_obj_t * make_orange_outline_btn(lv_obj_t * parent, const char * txt, lv_coord_t w, lv_coord_t h);  //创建橙色描边圆角按钮
static void cb_clock(lv_timer_t * t);  //定时器回调：每秒更新各界面顶部时钟标签
static void create_top_status_bar(lv_obj_t * top, lv_obj_t ** clock_lbl_out);  //创建顶部右侧状态栏（4G / WiFi / 时间）
static lv_obj_t * create_top_bar(lv_obj_t * parent, lv_obj_t ** clock_lbl_out,
	lv_obj_t * back_target, lv_group_t * encoder_group, lv_obj_t ** back_btn_out);  //创建顶部栏：可选返回键 + 状态栏
static lv_obj_t * add_encoder_top_btn(lv_obj_t * top, const char * txt, lv_coord_t x, lv_group_t * group);  //在顶部栏添加编码器可聚焦按钮
static void home_cap_update(void);  //商用洗无 AI 副标题，始终隐藏副标题标签
static void carousel_size_cb(lv_event_t * e);  //轮播区尺寸变化时重新布局
static void carousel_update_card_images(void);  //按当前选中程序刷新 5 张可见卡片图
static lv_coord_t carousel_slot_center_x(int slot);  //计算槽位相对轮播中心的水平偏移
static void carousel_wrap_relayout(void);  //轮播区整体布局：卡片位置/缩放/透明度与指示点
static int32_t wheel_mod_total(int32_t v);  //程序索引在 0..TOTAL_PROGRAMS-1 内循环取模
static void home_sync_encoder_focus_after_carousel_drag(void);  //触摸滑动改程序后对齐编码器焦点
static void home_carousel_step_program(int32_t delta);  //编码器/按键：程序索引 ±1
static void mode_card_encoder_cb(lv_event_t * e);  //中间卡：编辑模式下 LEFT/RIGHT 切换程序
static void wheel_pointer_cb(lv_event_t * e);  //轮播区按下/拖动/释放：滑动切换程序
static void mode_card_click(lv_event_t * e);  //轮播居中卡片点击：进入支付页
static void cb_load_screen(lv_event_t * e);  //通用界面加载事件回调，根据 user_data 切换屏幕
static void ui_layout_init(void);  //初始化轮播区布局参数（卡片尺寸、间距、拖动灵敏度）
static void style_screen_base(lv_obj_t * scr);  //设置屏幕基础样式（黑底、无边框）
static void style_obj_encoder_focus_outline(lv_obj_t * obj);
static void ui_encoder_group_add(lv_group_t * group, lv_obj_t * obj);  //控件创建后立即加入编码器 group
static void ui_encoder_group_add_no_outline(lv_group_t * group, lv_obj_t * obj);  //加入 group 但不显示焦点框
static void create_screens(void);  //创建全部屏幕对象并设固定分辨率
static void ui_set_encoder_group(lv_group_t * group);  //将编码器/键盘输入设备绑定到指定 focus group
static void ui_screen_load(lv_obj_t * scr);  //屏幕加载包装：清童锁/倒计时，切换 group 与页面逻辑
static void ui_idle_reset(void);  //重置空闲计时（有输入时调用）
static void ui_idle_on_screen_changed(lv_obj_t * scr);  //进入/离开待机页时暂停或恢复空闲计时
static void ui_idle_poll_pointer(void);  //检测鼠标移动并重置空闲计时
static void cb_idle_timeout(lv_timer_t * t);  //空闲超时：进入待机页
static void cb_indev_activity(lv_event_t * e);  //输入设备活动：重置空闲计时
static void ui_idle_indev_hook(void);  //为鼠标/编码器注册活动监听
static void ui_idle_init(void);  //创建空闲计时器并注册输入监听
static void cb_off_power_long(lv_event_t * e);  //待机页电源键长按 3 秒：进入主页
static void ui_apply_indev_long_press_ms(uint16_t ms);  //统一设置指针/编码器长按判定时间
static void running_child_lock_on_enter(void);  //童锁激活时的进入钩子（预留扩展）
static void running_child_lock_on_exit(void);  //童锁解除时的退出钩子（预留扩展）
static void running_child_lock_align_btn(void);  //将童锁按钮对齐到运行页中间栏右侧
static void running_child_lock_apply_locked(bool locked, bool silent_unlock);  //应用童锁锁定/解锁 UI 与 group
static void running_child_lock_remote_clear_if_leaving_running(lv_obj_t * target_scr);  //离开运行页时静默解除童锁
static void cb_running_child_lock_long(lv_event_t * e);  //童锁按钮长按：切换童锁开/关
static void build_home(void);  //构建主页：顶部栏、程序轮播、底部参数栏
static const ui_program_profile_t * program_profile_get(int32_t idx);  //获取指定程序索引的参数表项
static void program_format_time_label(uint32_t sec, char * buf, size_t buf_sz);  //格式化为首页时间标签文本
static void program_format_price_home(int32_t price, char * buf, size_t buf_sz);  //格式化为首页价格标签
static void program_format_price_pay(int32_t price, char * buf, size_t buf_sz);  //格式化为支付页价格标签
static void home_sync_program_labels(void);  //按当前选中程序刷新主页底部时间/温度/价格标签
static void pay_sync_price_label(void);  //按当前选中程序刷新支付页金额标签
static void running_screen_sync_mode_name(void);  //运行页程序名标签与 g_wheel_sel 保持一致
static void running_countdown_format(uint32_t sec, char * buf, size_t buf_sz);  //将剩余秒数格式化为 M:SS
static void running_countdown_update_label(void);  //刷新运行页倒计时标签显示
static void pay_done_timer_stop(void);  //停止支付完成页 2 秒自动跳转定时器
static void cb_pay_done_timer(lv_timer_t * t);  //支付完成页定时器回调：2 秒后进入运行页
static void pay_done_timer_start(void);  //启动支付完成页 2 秒自动跳转定时器
static void running_blink_stop(void);  //停止暂停时倒计时闪烁定时器并恢复标签可见
static void cb_running_blink(lv_timer_t * t);  //暂停时倒计时标签 500ms 闪烁定时器回调
static void running_countdown_stop(void);  //停止运行页倒计时定时器
static void running_countdown_reset_all(void);  //重置倒计时状态：清除暂停、闪烁与定时器
static void running_countdown_pause(void);  //暂停倒计时并启动时间标签闪烁
static void running_countdown_resume(void);  //恢复倒计时并停止闪烁
static void cb_running_runpause(lv_event_t * e);  //运行页启停按钮：暂停/恢复倒计时
static void cb_running_countdown(lv_timer_t * t);  //运行页每秒倒计时回调，归零后跳转结束页
static void running_countdown_arm(void);  //若剩余时间>0 则启动 1 秒倒计时定时器
static void running_countdown_start(void);  //进入运行页时按程序时长初始化并开始倒计时
static void cb_kuaixi_running_start(lv_event_t * e);  //快洗运行页：点击运行后显示底部状态文字
static void cb_kuaixi_running_add(lv_event_t * e);  //快洗运行页：点击添衣后隐藏底部状态文字
static void build_running(void);  //构建运行页：背景、顶部栏、程序名/倒计时、童锁
static void build_end(void);  //构建洗涤结束页：返回、图标与提示文字
static void build_pay(void);  //构建支付页：二维码、金额与支付提示
static void build_pay_done(void);  //构建支付完成页：图标与 2 秒后自动进运行页
static void build_off(void);  //构建关机/待机页：仅顶部栏与启停/电源

// 可移植字体绑定（通过字体适配层统一选择自定义/回退字体）
static const lv_font_t * s_font_sc_20;
static const lv_font_t * s_font_sc_30;
static const lv_font_t * s_font_sc_35;
static const lv_font_t * s_font_sc_50;
static const lv_font_t * s_font_sc_125;

static void ui_set_obj_font(lv_obj_t * obj, const lv_font_t * font)
{
	if(obj != NULL && font != NULL) {
		lv_obj_set_style_text_font(obj, font, LV_PART_MAIN);
	}
}

//绑定中文字体并应用到 LVGL 默认主题
static void ui_apply_chinese_font(void)  //绑定中文字体并应用到 LVGL 默认主题
{
	s_font_sc_20 = ui_font_get_sc_20();
	s_font_sc_30 = ui_font_get_sc_30();
	s_font_sc_35 = ui_font_get_sc_35();
	s_font_sc_50 = ui_font_get_sc_50();
	s_font_sc_125 = ui_font_get_sc_125();

	lv_display_t * d = lv_display_get_default();
	if(d != NULL && s_font_sc_20 != NULL) {
		lv_theme_t * th = lv_theme_default_init(d, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_RED),
																						LV_THEME_DEFAULT_DARK, s_font_sc_20);
		lv_display_set_theme(d, th);
	}
}// win中文函数




//以下是按钮函数的定义
//创建文本按钮
static lv_obj_t * make_text_btn(lv_obj_t * parent, const char * txt, lv_coord_t w, lv_coord_t h)  //创建透明背景文本按钮
{
	lv_obj_t * b = lv_button_create(parent);
	lv_obj_set_size(b, w, h);
	lv_obj_set_style_pad_all(b, 0, LV_PART_MAIN);
	lv_obj_set_style_bg_opa(b, LV_OPA_TRANSP, LV_PART_MAIN);//背景透明
	lv_obj_set_style_border_width(b, 0, LV_PART_MAIN);//边框宽度为0
	lv_obj_set_style_shadow_width(b, 0, LV_PART_MAIN);//阴影宽度为0
	lv_obj_t * l = lv_label_create(b);
	lv_label_set_text(l, txt);
	lv_obj_set_style_text_color(l, lv_color_hex(COL_TEXT), LV_PART_MAIN);//文本颜色 COL_TEXT
	ui_set_obj_font(l, s_font_sc_20);
	lv_obj_center(l);//文本居中
	return b;
}//创建文本按钮

//创建橙色填充按钮
static lv_obj_t * make_orange_fill_btn(lv_obj_t * parent, const char * txt, lv_coord_t w, lv_coord_t h)  //创建橙色实心圆角按钮
{
	lv_obj_t * b = lv_button_create(parent);
	lv_obj_set_size(b, w, h);
	lv_obj_set_style_radius(b, 8, LV_PART_MAIN);                              //圆角为 8
	lv_obj_set_style_bg_opa(b, LV_OPA_COVER, LV_PART_MAIN);                   //背景不透明
	lv_obj_set_style_bg_color(b, lv_color_hex(COL_ORANGE), LV_PART_MAIN);     //背景颜色 COL_ORANGE
	lv_obj_t * l = lv_label_create(b);
	lv_label_set_text(l, txt);
	lv_obj_set_style_text_color(l, lv_color_hex(COL_TEXT), LV_PART_MAIN);     //文本颜色 COL_TEXT
	lv_obj_center(l);
	return b;
}//创建橙色填充按钮

//创建橙色描边按钮
static lv_obj_t * make_orange_outline_btn(lv_obj_t * parent, const char * txt, lv_coord_t w, lv_coord_t h)  //创建橙色描边圆角按钮
{
	lv_obj_t * b = lv_button_create(parent);
	lv_obj_set_size(b, w, h);
	lv_obj_set_style_radius(b, 8, LV_PART_MAIN);                              //圆角为 8
	lv_obj_set_style_bg_opa(b, LV_OPA_TRANSP, LV_PART_MAIN);                  //背景透明
	lv_obj_set_style_border_width(b, 2, LV_PART_MAIN);                        //边框宽度为 2
	lv_obj_set_style_border_color(b, lv_color_hex(COL_ORANGE), LV_PART_MAIN); //边框颜色 COL_ORANGE
	lv_obj_t * l = lv_label_create(b);
	lv_label_set_text(l, txt);
	lv_obj_set_style_text_color(l, lv_color_hex(COL_ORANGE), LV_PART_MAIN);   //文本颜色 COL_ORANGE
	lv_obj_center(l);
	return b;
}//创建橙色描边按钮

//时间更新
static void cb_clock(lv_timer_t * t)     //时间更新函数
{
	(void)t;
	static uint32_t s_clock_seconds = 16u * 3600u + 30u * 60u;
	uint32_t hour = (s_clock_seconds / 3600u) % 24u;
	uint32_t minute = (s_clock_seconds / 60u) % 60u;
	char buf[8];
	snprintf(buf, sizeof(buf), "%02u:%02u", (unsigned)hour, (unsigned)minute);
	if(g_lbl_clock != NULL) {
		lv_label_set_text(g_lbl_clock, buf);
	}
	if(g_lbl_clock_running != NULL) {
		lv_label_set_text(g_lbl_clock_running, buf);
	}
	if(g_lbl_clock_end != NULL) {
		lv_label_set_text(g_lbl_clock_end, buf);
	}
	if(g_lbl_clock_pay != NULL) {
		lv_label_set_text(g_lbl_clock_pay, buf);
	}
	if(g_lbl_clock_pay_done != NULL) {
		lv_label_set_text(g_lbl_clock_pay_done, buf);
	}
	if(g_lbl_clock_off != NULL) {
		lv_label_set_text(g_lbl_clock_off, buf);
	}
	ui_idle_poll_pointer();  //检测鼠标移动并重置空闲计时
	s_clock_seconds = (s_clock_seconds + 1u) % (24u * 3600u);
}

/* 顶部栏右侧：4G / WiFi / 时间（主页与运行页共用） */
static void create_top_status_bar(lv_obj_t * top, lv_obj_t ** clock_lbl_out)  //创建顶部右侧状态栏（4G / WiFi / 时间）
{
	lv_obj_t * status = lv_obj_create(top);
	lv_obj_set_size(status, LV_PCT(8), LV_PCT(100));
	lv_obj_set_pos(status, LV_PCT(90), 0);
	lv_obj_set_style_bg_opa(status, LV_OPA_TRANSP, LV_PART_MAIN);
	lv_obj_set_style_border_width(status, 0, LV_PART_MAIN);
	lv_obj_set_style_pad_all(status, 0, LV_PART_MAIN);
	lv_obj_set_style_radius(status, 0, LV_PART_MAIN);

	lv_obj_t * t4g = lv_label_create(status);
	lv_label_set_text(t4g, "4G");
	lv_obj_align(t4g, LV_ALIGN_LEFT_MID, 0, 0);
	lv_obj_set_style_text_color(t4g, lv_color_hex(COL_TEXT), LV_PART_MAIN);
	ui_set_obj_font(t4g, s_font_sc_20);

	lv_obj_t * tw = lv_label_create(status);
	lv_obj_set_style_text_font(tw, &lv_font_montserrat_16, LV_PART_MAIN);
	lv_label_set_text(tw, LV_SYMBOL_WIFI);
	lv_obj_align(tw, LV_ALIGN_CENTER, -8, 0);
	lv_obj_set_style_text_color(tw, lv_color_hex(COL_TEXT), LV_PART_MAIN);

	lv_obj_t * clock = lv_label_create(status);
	lv_label_set_text(clock, "16:30");
	lv_obj_align(clock, LV_ALIGN_RIGHT_MID, 0, 0);
	lv_obj_set_style_text_color(clock, lv_color_hex(COL_TEXT), LV_PART_MAIN);
	ui_set_obj_font(clock, s_font_sc_20);
	if(clock_lbl_out != NULL) {
		*clock_lbl_out = clock;
	}

	static bool s_clock_timer_started = false;
	if(!s_clock_timer_started) {
		lv_timer_create(cb_clock, 1000, NULL);
		s_clock_timer_started = true;
	} else if(clock_lbl_out != NULL && *clock_lbl_out != NULL) {
		cb_clock(NULL);  //刷新时钟
	}
}

/* 顶部栏：可选返回 + 4G / WiFi / 时间（启停、电源由各界面单独添加） */
static lv_obj_t * create_top_bar(lv_obj_t * parent, lv_obj_t ** clock_lbl_out,
	lv_obj_t * back_target, lv_group_t * encoder_group, lv_obj_t ** back_btn_out)  //创建顶部栏
{
	lv_obj_t * top = lv_obj_create(parent);
	lv_obj_set_size(top, LV_PCT(100), LV_PCT(10));
	lv_obj_set_pos(top, 0, 0);
	lv_obj_set_style_bg_opa(top, LV_OPA_TRANSP, LV_PART_MAIN);
	lv_obj_set_style_border_width(top, 0, LV_PART_MAIN);
	lv_obj_set_style_pad_all(top, 0, LV_PART_MAIN);
	lv_obj_set_style_radius(top, 0, LV_PART_MAIN);

	if(back_target != NULL) {
		LV_IMAGE_DECLARE(back);
		lv_obj_t * imgbtn_back = lv_imgbtn_create(top);
		lv_imgbtn_set_src(imgbtn_back, LV_IMGBTN_STATE_RELEASED, NULL, &back, NULL);
		lv_obj_align(imgbtn_back, LV_ALIGN_LEFT_MID, 20, 0);
		lv_obj_add_event_cb(imgbtn_back, cb_load_screen, LV_EVENT_CLICKED, back_target);
		lv_obj_remove_flag(imgbtn_back, LV_OBJ_FLAG_SCROLLABLE);
		if(encoder_group != NULL) {
			ui_encoder_group_add(encoder_group, imgbtn_back);
		}
		if(back_btn_out != NULL) {
			*back_btn_out = imgbtn_back;
		}
	}

	create_top_status_bar(top, clock_lbl_out);  //创建顶部右侧状态栏（4G / WiFi / 时间）
	return top;
}

//在顶部栏添加编码器可聚焦的启停/电源类文本按钮
static lv_obj_t * add_encoder_top_btn(lv_obj_t * top, const char * txt, lv_coord_t x, lv_group_t * group)  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮
{
	lv_obj_t * btn = make_text_btn(top, txt, 80, 32);  //创建透明背景文本按钮
	lv_obj_align(btn, LV_ALIGN_LEFT_MID, x, 0);
	lv_obj_remove_flag(btn, LV_OBJ_FLAG_SCROLLABLE);
	if(group != NULL) {
		ui_encoder_group_add(group, btn);
	}
	return btn;
}

//商用洗无 AI 智洗副标题，始终隐藏
static void home_cap_update(void)  //商用洗无 AI 副标题
{
	if(g_cap_subtitle == NULL) return;
	lv_obj_set_style_opa(g_cap_subtitle, LV_OPA_TRANSP, LV_PART_MAIN);
}

//轮播区函数定义
//轮播区尺寸变化事件回调函数
static void carousel_size_cb(lv_event_t * e)  //轮播区尺寸变化时重新布局
{
	(void)e;
	carousel_wrap_relayout();  //重排轮播布局
}

//按当前选中程序刷新 5 张可见卡片图（槽位 i 显示 g_wheel_sel + (i - center)）
static void carousel_update_card_images(void)  //按当前选中程序刷新 5 张可见卡片图
{
	for(int i = 0; i < CAROUSEL_VISIBLE_SLOTS; i++) {
		if(g_mode_card_imgs[i] == NULL) continue;
		int32_t prog_idx = wheel_mod_total(g_wheel_sel + (int32_t)(i - CAROUSEL_CENTER_SLOT));  //程序索引取模
		lv_image_set_src(g_mode_card_imgs[i], g_program_imgs[prog_idx]);
	}
}

/* 5 张卡片中心相对轮播区中心的 X 偏移：外侧两对更紧，靠近中心两对更疏 */
static lv_coord_t carousel_slot_center_x(int slot)  //计算槽位相对轮播中心的水平偏移
{
	switch(slot) {
		case 0: return -(s_mode_gap_inner + s_mode_gap_outer);
		case 1: return -s_mode_gap_inner;
		case 2: return 0;
		case 3: return s_mode_gap_inner;
		case 4: return s_mode_gap_inner + s_mode_gap_outer;
		default: return 0;
	}
}

//轮播区布局
static void carousel_wrap_relayout(void)  //重排轮播布局
{
	if(g_mode_carousel == NULL) return;
	lv_coord_t mw = lv_obj_get_width(g_mode_carousel);
	lv_coord_t mh = lv_obj_get_height(g_mode_carousel);
	home_cap_update();//副标题更新回调函数
	if(mw < 16 || mh < 16) return;

	carousel_update_card_images();  //按当前选中程序刷新 5 张可见卡片图

	lv_coord_t cx = mw / 2;
	lv_coord_t cy = mh / 2;
	/* 五个圆同一水平中线，相对区域垂直中心略向上 */
	const lv_coord_t y = cy - s_mode_card_sz / 2 - s_mode_row_shift_up;

	for(int i = 0; i < CAROUSEL_VISIBLE_SLOTS; i++) {
		if(g_mode_cards[i] == NULL) continue;
		float x_rel = (float)(i - CAROUSEL_CENTER_SLOT) + g_wheel_turn;

		lv_coord_t x = cx + carousel_slot_center_x(i)  //计算槽位相对轮播中心的水平偏移
			+ (lv_coord_t)(g_wheel_turn * (float)s_mode_step_x) - s_mode_card_sz / 2;
		float af = x_rel < 0.f ? -x_rel : x_rel;
		if(af > 2.5f) af = 2.5f;

		lv_obj_set_pos(g_mode_cards[i], x, y);

		float t = 1.0f - ((af > 2.0f) ? 2.0f : af) / 2.0f;
		int32_t scale = MODE_SCALE_MIN + (int32_t)((float)(MODE_SCALE_MAX - MODE_SCALE_MIN) * t);
		lv_obj_set_style_transform_pivot_x(g_mode_cards[i], s_mode_card_sz / 2, LV_PART_MAIN);
		lv_obj_set_style_transform_pivot_y(g_mode_cards[i], s_mode_card_sz / 2, LV_PART_MAIN);
		lv_obj_set_style_transform_scale_x(g_mode_cards[i], scale, LV_PART_MAIN);
		lv_obj_set_style_transform_scale_y(g_mode_cards[i], scale, LV_PART_MAIN);

		// 调整透明度计算逻辑：中心(af=0)透明度约255，最两边(af=2)透明度约为 255 * 30% ≈ 76
		lv_opa_t opa;
		if(af <= 0.1f) opa = LV_OPA_COVER;
		else if(af >= 2.0f) opa = (lv_opa_t)(LV_OPA_30);
		else {
			opa = (lv_opa_t)(255 - (int)(af * (255 - 76) / 2.0f));
		}
		lv_obj_set_style_opa(g_mode_cards[i], opa, LV_PART_MAIN);
	}

	if(g_mode_cards[CAROUSEL_CENTER_SLOT] != NULL) {
		lv_obj_move_foreground(g_mode_cards[CAROUSEL_CENTER_SLOT]);
	}

	lv_coord_t dot_w[TOTAL_PROGRAMS];
	lv_coord_t total_w = 0;
	const lv_coord_t dot_gap = 8;
	for(int i = 0; i < TOTAL_PROGRAMS; i++) {
		dot_w[i] = (i == g_wheel_sel) ? 13 : 10;
		total_w += dot_w[i];
		if(i < TOTAL_PROGRAMS - 1) total_w += dot_gap;
	}

	lv_coord_t x_cursor = -total_w / 2;
	for(int i = 0; i < TOTAL_PROGRAMS; i++) {
		if(g_mode_dots[i] == NULL) {
			x_cursor += dot_w[i] + dot_gap;
			continue;
		}

		lv_obj_set_size(g_mode_dots[i], dot_w[i], dot_w[i]);
		lv_obj_align(g_mode_dots[i], LV_ALIGN_CENTER, x_cursor + dot_w[i] / 2, 0);
		lv_obj_set_style_bg_color(g_mode_dots[i], lv_color_hex((i == g_wheel_sel) ? COL_TEXT : COL_DIM), LV_PART_MAIN);
		x_cursor += dot_w[i] + dot_gap;
	}
}

//程序索引在 0..TOTAL_PROGRAMS-1 范围内循环
static int32_t wheel_mod_total(int32_t v)  //程序索引取模
{
	v %= TOTAL_PROGRAMS;
	if(v < 0) v += TOTAL_PROGRAMS;
	return v;
}

//触摸滑动改程序后，将编码器焦点对齐到中间卡
static void home_sync_encoder_focus_after_carousel_drag(void)
{
	if(g_group_home == NULL) return;
	if(g_mode_cards[CAROUSEL_CENTER_SLOT] != NULL) {
		lv_group_focus_obj(g_mode_cards[CAROUSEL_CENTER_SLOT]);
	}
}

static void home_carousel_step_program(int32_t delta)
{
	g_wheel_sel = wheel_mod_total((int32_t)g_wheel_sel + delta);
	g_wheel_turn = 0.f;
	carousel_wrap_relayout();
	home_cap_update();
	home_sync_program_labels();
}

/* 仅中间卡入 group：获焦进入编辑模式，旋转编码器发送 LEFT/RIGHT 切换程序 */
static void mode_card_encoder_cb(lv_event_t * e)
{
	lv_event_code_t code = lv_event_get_code(e);

	if(code == LV_EVENT_FOCUSED) {
		if(g_group_home != NULL) {
			lv_group_set_editing(g_group_home, true);
		}
		return;
	}
	if(code == LV_EVENT_DEFOCUSED) {
		if(g_group_home != NULL) {
			lv_group_set_editing(g_group_home, false);
		}
		return;
	}
	if(code != LV_EVENT_KEY) return;
	if(g_ui_child_lock) return;

	uint32_t key = lv_event_get_key(e);
	if(key == LV_KEY_RIGHT) {
		home_carousel_step_program(1);
	}
	else if(key == LV_KEY_LEFT) {
		home_carousel_step_program(-1);
	}
}

//轮播区点击事件，处理轮播区的按下、拖动、释放等事件，实现卡片的滑动切换和点击判定
static void wheel_pointer_cb(lv_event_t * e)  //轮播区按下/拖动/释放
{
	if(g_ui_child_lock) return;
	lv_event_code_t code = lv_event_get_code(e);
	lv_indev_t * indev = lv_indev_get_act();
	if(indev == NULL) return;
	lv_point_t p;
	lv_indev_get_point(indev, &p);

	if(code == LV_EVENT_PRESSED) {
		g_wheel_press_x = p.x;
		g_wheel_dragging = true;
		g_wheel_turn = 0.f;
		g_wheel_moved = false;
		return;
	}

	if(code == LV_EVENT_PRESSING && g_wheel_dragging) {
		lv_coord_t dx = p.x - g_wheel_press_x;
		g_wheel_turn = (float)dx / (float)s_mode_step_x;
		carousel_wrap_relayout();  //重排轮播布局
		return;
	}

	if(code == LV_EVENT_RELEASED && g_wheel_dragging) {
		lv_coord_t dx = p.x - g_wheel_press_x;
		g_wheel_dragging = false;

		if(LV_ABS(dx) < 14) {
			g_wheel_turn = 0.f;
			carousel_wrap_relayout();  //重排轮播布局
			return;
		}

		/* 左滑(dx<0)：索引前进；右滑：索引后退。|dx| 每满一格 s_mode_drag_snap_px 多切 1 个功能 */
		int k;
		if(dx < 0) k = (-dx) / s_mode_drag_snap_px;
		else k = dx / s_mode_drag_snap_px;
		if(k == 0) k = 1;

		int32_t delta = (dx < 0) ? k : -k;
		g_wheel_sel = wheel_mod_total((int32_t)g_wheel_sel + delta);  //程序索引取模

		g_wheel_turn = 0.f;
		g_wheel_moved = true;
		carousel_wrap_relayout();						//轮播区布局
		home_cap_update();								//副标题更新回调函数
		home_sync_program_labels();  //刷新主页程序标签
		home_sync_encoder_focus_after_carousel_drag();
	}
}

//轮播区卡片鼠标点击选中事件（仅居中槽位进入支付页）
static void mode_card_click(lv_event_t * e)  //轮播居中卡片点击
{
	if(g_ui_child_lock) return;
	if(g_wheel_moved) return;
	intptr_t slot = (intptr_t)lv_event_get_user_data(e);
	if(slot != CAROUSEL_CENTER_SLOT) return;
	ui_screen_load(g_scr_pay);  //加载支付页
}







static void cb_load_screen(lv_event_t * e)  //通用界面加载事件回调函数，根据事件参数加载对应界面
{
	if(g_ui_child_lock) return;
	lv_obj_t * scr = (lv_obj_t *)lv_event_get_user_data(e);
	if(scr == NULL) return;
	ui_screen_load(scr);  //加载目标屏幕
}

static void ui_layout_init(void)    //界面布局参数初始化
{
	s_mode_card_sz = 380;             //轮播区卡片尺寸（px）
	s_mode_step_x = 215;              //拖动换算基准（平均槽距，px）
	s_mode_gap_outer = 200;           //第1-2、第4-5 间距（较窄）
	s_mode_gap_inner = 240;           //第2-3、第3-4 间距（较宽，离中心更远）
	s_mode_row_shift_up = 0;          //轮播区卡片相对水平中心向上偏移（px），使卡片位置更协调
	s_mode_drag_snap_px = 150;        //每满一格 s_mode_drag_snap_px 多切 1 个功能
}

//设置屏幕基础样式（黑底、无边框）
static void style_screen_base(lv_obj_t * scr)  //设置屏幕基础样式（黑底、无边框）
{
	lv_obj_set_style_bg_color(scr, lv_color_hex(COL_BG), LV_PART_MAIN);   //设置 背景颜色 COL_BG
	lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, LV_PART_MAIN);             //设置 背景不透明
	lv_obj_set_style_border_width(scr, 0, LV_PART_MAIN);                  //设置 边框宽度为 0
	lv_obj_set_style_pad_all(scr, 0, LV_PART_MAIN);                       //设置 内边距为 0
	lv_obj_set_style_radius(scr,0,LV_PART_MAIN);                          //设置 圆角为 0
}

/* 默认主题只为部分控件加了 LV_STATE_FOCUS_KEY 描边；imagebutton 等需自行设置。
 * 颜色与粗细对齐 lv_theme_default 的 outline_primary（theme 主色、LV_OPA_50、dpx 3 线宽与内边距） */
//为控件设置编码器/按键焦点描边样式
static void style_obj_encoder_focus_outline(lv_obj_t * obj)  //为控件设置编码器/按键焦点描边样式
{
	if(obj == NULL) return;
	lv_display_t * disp = lv_obj_get_display(obj);
	lv_coord_t ow = 3;
	if(disp != NULL) ow = (lv_coord_t)lv_display_dpx(disp, 3);

	lv_obj_set_style_outline_color(obj, lv_color_hex(COL_TEXT), LV_STATE_FOCUS_KEY);
	lv_obj_set_style_outline_width(obj, ow, LV_STATE_FOCUS_KEY);
	lv_obj_set_style_outline_pad(obj, ow, LV_STATE_FOCUS_KEY);
	lv_obj_set_style_outline_opa(obj, LV_OPA_50, LV_STATE_FOCUS_KEY);
}

/* 编码器 group：控件创建后立即按顺序加入 */
static void ui_encoder_group_add(lv_group_t * group, lv_obj_t * obj)
{
	if(group == NULL || obj == NULL) return;
	lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICK_FOCUSABLE);
	style_obj_encoder_focus_outline(obj);
	lv_group_add_obj(group, obj);
}

/* 轮播卡片：编码器可选程序，但不显示焦点描边 */
static void ui_encoder_group_add_no_outline(lv_group_t * group, lv_obj_t * obj)
{
	if(group == NULL || obj == NULL) return;
	lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICK_FOCUSABLE);
	lv_obj_set_style_outline_width(obj, 0, LV_STATE_FOCUS_KEY);
	lv_obj_set_style_outline_opa(obj, LV_OPA_TRANSP, LV_STATE_FOCUS_KEY);
	lv_group_add_obj(group, obj);
}

static void create_screens(void) //创建界面，并按当前显示分辨率设满屏宽高
{
	g_scr_off = lv_obj_create(NULL);
	g_scr_home = lv_obj_create(NULL);
	g_scr_running = lv_obj_create(NULL);
	g_scr_end = lv_obj_create(NULL);
	g_scr_pay = lv_obj_create(NULL);
	g_scr_pay_done = lv_obj_create(NULL);
	style_screen_base(g_scr_off);  //设置屏幕基础样式（黑底、无边框）
	style_screen_base(g_scr_home);             //主页
	style_screen_base(g_scr_running);          //运行
	style_screen_base(g_scr_end);                //运行结束
	style_screen_base(g_scr_pay);                  //支付
	style_screen_base(g_scr_pay_done);             //支付完成
	lv_obj_set_size(g_scr_off, UI_FIXED_W, UI_FIXED_H);
	lv_obj_set_size(g_scr_home, UI_FIXED_W, UI_FIXED_H);              //主页宽高
	lv_obj_set_size(g_scr_running, UI_FIXED_W, UI_FIXED_H);           //运行宽高
	lv_obj_set_size(g_scr_end, UI_FIXED_W, UI_FIXED_H);
	lv_obj_set_size(g_scr_pay, UI_FIXED_W, UI_FIXED_H);
	lv_obj_set_size(g_scr_pay_done, UI_FIXED_W, UI_FIXED_H);
}

//将编码器/键盘输入设备绑定到指定 focus group
static void ui_set_encoder_group(lv_group_t * group)  //切换编码器 group
{
	if(group == NULL) return;
	lv_indev_t * indev = NULL;
	while((indev = lv_indev_get_next(indev)) != NULL) {
		lv_indev_type_t type = lv_indev_get_type(indev);
		if(type == LV_INDEV_TYPE_ENCODER || type == LV_INDEV_TYPE_KEYPAD) {
			lv_indev_set_group(indev, group);
		}
	}
}

// 屏幕加载的包装：加载后切换编码器 group
static void ui_screen_load(lv_obj_t * scr)  //加载目标屏幕
{
	if(scr == NULL) return;

	running_child_lock_remote_clear_if_leaving_running(scr);  //离开运行页时静默解除童锁

	if(scr != g_scr_running) {
		running_countdown_reset_all();  //重置倒计时状态
	}
	if(scr != g_scr_pay_done) {
		pay_done_timer_stop();  //停止支付完成页 2 秒自动跳转定时器
	}

	lv_screen_load(scr);

	if(scr == g_scr_off) {
		ui_set_encoder_group(g_group_off);  //切换编码器 group
	}
	else if(scr == g_scr_home) {
		ui_set_encoder_group(g_group_home);  //切换编码器 group
	}
	else if(scr == g_scr_running) {
		ui_set_encoder_group(g_group_running);  //切换编码器 group
		running_screen_sync_mode_name();  //运行页程序名标签与 g_wheel_sel 保持一致
		running_countdown_start();  //初始化并开始倒计时
	}
	else if(scr == g_scr_end) {
		ui_set_encoder_group(g_group_end);  //切换编码器 group
	}
	else if(scr == g_scr_pay) {
		ui_set_encoder_group(g_group_pay);  //切换编码器 group
		pay_sync_price_label();  //刷新支付页金额
	}
	else if(scr == g_scr_pay_done) {
		ui_set_encoder_group(g_group_pay_done);  //切换编码器 group
		pay_done_timer_start();  //启动支付完成页 2 秒自动跳转定时器
	}
	else {
		ui_set_encoder_group(g_ui_group);  //切换编码器 group
	}
	ui_idle_on_screen_changed(scr);  //待机页暂停空闲计时，其它页恢复
}

//重置空闲计时（有输入时调用）
static void ui_idle_reset(void)
{
	if(g_idle_timer == NULL) return;
	if(lv_scr_act() == g_scr_off) return;
	lv_timer_reset(g_idle_timer);
	lv_timer_resume(g_idle_timer);
}

//进入/离开待机页时暂停或恢复空闲计时
static void ui_idle_on_screen_changed(lv_obj_t * scr)
{
	if(g_idle_timer == NULL) return;
	if(scr == g_scr_off) {
		lv_timer_pause(g_idle_timer);
		g_idle_last_ptr_x = -1;
		g_idle_last_ptr_y = -1;
		if(g_off_btn_power != NULL && g_group_off != NULL) {
			lv_group_focus_obj(g_off_btn_power);
		}
	}
	else {
		ui_idle_reset();
	}
}

//检测鼠标移动并重置空闲计时
static void ui_idle_poll_pointer(void)
{
	if(lv_scr_act() == g_scr_off) return;

	lv_indev_t * indev = NULL;
	while((indev = lv_indev_get_next(indev)) != NULL) {
		if(lv_indev_get_type(indev) != LV_INDEV_TYPE_POINTER) continue;

		lv_point_t p;
		lv_indev_get_point(indev, &p);
		if(g_idle_last_ptr_x >= 0 &&
		   (p.x != g_idle_last_ptr_x || p.y != g_idle_last_ptr_y)) {
			ui_idle_reset();
		}
		g_idle_last_ptr_x = p.x;
		g_idle_last_ptr_y = p.y;
		break;
	}
}

//空闲超时：进入待机页
static void cb_idle_timeout(lv_timer_t * t)
{
	(void)t;
	if(g_scr_off == NULL) return;
	if(lv_scr_act() == g_scr_off) return;
	ui_screen_load(g_scr_off);
}

//输入设备活动：重置空闲计时
static void cb_indev_activity(lv_event_t * e)
{
	lv_event_code_t code = lv_event_get_code(e);
	if(code == LV_EVENT_PRESSED || code == LV_EVENT_PRESSING || code == LV_EVENT_RELEASED ||
	   code == LV_EVENT_CLICKED || code == LV_EVENT_LONG_PRESSED || code == LV_EVENT_LONG_PRESSED_REPEAT ||
	   code == LV_EVENT_KEY || code == LV_EVENT_ROTARY || code == LV_EVENT_GESTURE) {
		ui_idle_reset();
	}
}

//为鼠标/编码器/键盘注册活动监听
static void ui_idle_indev_hook(void)
{
	lv_indev_t * indev = NULL;
	while((indev = lv_indev_get_next(indev)) != NULL) {
		lv_indev_type_t type = lv_indev_get_type(indev);
		if(type == LV_INDEV_TYPE_POINTER || type == LV_INDEV_TYPE_ENCODER || type == LV_INDEV_TYPE_KEYPAD) {
			lv_indev_add_event_cb(indev, cb_indev_activity, LV_EVENT_ALL, NULL);
		}
	}
}

//创建空闲计时器并注册输入监听 3分钟
static void ui_idle_init(void)
{
	if(g_idle_timer == NULL) {
		g_idle_timer = lv_timer_create(cb_idle_timeout, 180000u, NULL);
	}
	ui_idle_indev_hook();
	ui_idle_reset();
}

//待机页电源键长按 3 秒：进入主页
static void cb_off_power_long(lv_event_t * e)
{
	(void)e;
	if(lv_scr_act() != g_scr_off) return;
	ui_screen_load(g_scr_home);
}

//统一设置指针/编码器长按判定时间
static void ui_apply_indev_long_press_ms(uint16_t ms)  //统一设置指针/编码器长按判定时间
{
	lv_indev_t * indev = NULL;
	while((indev = lv_indev_get_next(indev)) != NULL) {
		lv_indev_type_t t = lv_indev_get_type(indev);
		if(t == LV_INDEV_TYPE_POINTER || t == LV_INDEV_TYPE_ENCODER) {
			lv_indev_set_long_press_time(indev, ms);
		}
	}
}

//童锁激活时的进入钩子（预留扩展）
static void running_child_lock_on_enter(void)  //童锁激活时的进入钩子（预留扩展）
{
}

//童锁解除时的退出钩子（预留扩展）
static void running_child_lock_on_exit(void)  //童锁解除时的退出钩子（预留扩展）
{
}

//将童锁按钮对齐到运行页中间栏右侧
static void running_child_lock_align_btn(void)  //将童锁按钮对齐到运行页中间栏右侧
{
	if(g_running_child_lock_btn == NULL || g_running_mid == NULL) return;
	lv_obj_t * root = lv_obj_get_parent(g_running_mid);
	if(root != NULL) {
		lv_obj_update_layout(root);
	}
	lv_obj_align_to(g_running_child_lock_btn, g_running_mid, LV_ALIGN_RIGHT_MID, 80, 0);
}

//应用童锁锁定/解锁 UI 与编码器 group 状态
static void running_child_lock_apply_locked(bool locked, bool silent_unlock)  //应用童锁锁定/解锁 UI 与编码器 group 状态
{
	if(g_running_child_lock_btn == NULL || g_group_running == NULL) return;

	bool* need_child_lock = &g_ui_child_lock;
	if(locked) {
		*need_child_lock = true;
		running_child_lock_on_enter();  //童锁激活时的进入钩子（预留扩展）
	}
	else {
		*need_child_lock = false;
		if(!silent_unlock) {
			running_child_lock_on_exit();  //童锁解除时的退出钩子（预留扩展）
		}
	}

	g_ui_child_lock = locked;

	if(locked) {
		lv_obj_set_style_bg_opa(g_running_child_lock_btn, LV_OPA_COVER, LV_PART_MAIN);
		lv_obj_set_style_bg_color(g_running_child_lock_btn, lv_color_hex(COL_CHILD_LOCK_RED), LV_PART_MAIN);
		lv_obj_set_style_border_width(g_running_child_lock_btn, 2, LV_PART_MAIN);
		lv_obj_set_style_border_color(g_running_child_lock_btn, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		if(g_running_child_lock_lbl != NULL) {
			lv_obj_set_style_text_color(g_running_child_lock_lbl, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		}
		if(g_running_lock_blocker != NULL) {
			lv_obj_remove_flag(g_running_lock_blocker, LV_OBJ_FLAG_HIDDEN);
		}
		lv_group_remove_all_objs(g_group_running);
		lv_group_add_obj(g_group_running, g_running_child_lock_btn);
		lv_group_focus_obj(g_running_child_lock_btn);
		if(g_running_lock_blocker != NULL) {
			lv_obj_move_foreground(g_running_lock_blocker);
		}
		lv_obj_move_foreground(g_running_child_lock_btn);
	}
	else {
		lv_obj_set_style_bg_opa(g_running_child_lock_btn, LV_OPA_COVER, LV_PART_MAIN);
		lv_obj_set_style_bg_color(g_running_child_lock_btn, lv_color_hex(COL_CHILD_LOCK_WHITE), LV_PART_MAIN);
		lv_obj_set_style_border_width(g_running_child_lock_btn, 2, LV_PART_MAIN);
		lv_obj_set_style_border_color(g_running_child_lock_btn, lv_color_hex(0xBBBBBB), LV_PART_MAIN);
		if(g_running_child_lock_lbl != NULL) {
			lv_obj_set_style_text_color(g_running_child_lock_lbl, lv_color_hex(0x222222), LV_PART_MAIN);
		}
		if(g_running_lock_blocker != NULL) {
			lv_obj_add_flag(g_running_lock_blocker, LV_OBJ_FLAG_HIDDEN);
		}
		if(g_running_btn_back != NULL) {
			lv_group_remove_all_objs(g_group_running);
			lv_group_add_obj(g_group_running, g_running_btn_back);
			if(g_running_btn_runpause != NULL) {
				lv_group_add_obj(g_group_running, g_running_btn_runpause);
			}
			if(g_running_btn_power != NULL) {
				lv_group_add_obj(g_group_running, g_running_btn_power);
			}
			lv_group_add_obj(g_group_running, g_running_child_lock_btn);
		}
		ui_set_encoder_group(g_group_running);  //切换编码器 group
	}
}

//离开运行页时静默解除童锁
static void running_child_lock_remote_clear_if_leaving_running(lv_obj_t * target_scr)  //离开运行页时静默解除童锁
{
	if(target_scr == NULL || g_scr_running == NULL) return;
	if(!g_ui_child_lock) return;
	if(lv_scr_act() == NULL) return;
	if(lv_scr_act() != g_scr_running) return;
	if(target_scr == g_scr_running) return;
	running_child_lock_apply_locked(false, true);  //应用童锁锁定/解锁 UI 与编码器 group 状态
}

//童锁按钮长按：切换童锁开/关
static void cb_running_child_lock_long(lv_event_t * e)  //童锁按钮长按
{
	if(lv_event_get_code(e) != LV_EVENT_LONG_PRESSED) return;
	if(!g_ui_child_lock) {
		running_child_lock_apply_locked(true, false);  //应用童锁锁定/解锁 UI 与编码器 group 状态
	}
	else {
		running_child_lock_apply_locked(false, false);  //应用童锁锁定/解锁 UI 与编码器 group 状态
	}
}







static void build_home(void)   //创建主页
{
		lv_obj_t * scr = g_scr_home;

		lv_obj_t * root = lv_obj_create(scr);
		lv_obj_set_size(root, LV_PCT(100), LV_PCT(100));                //root大小
		lv_obj_set_pos(root, 0, 0);                                     //root位置
		lv_obj_set_style_bg_opa(root, LV_OPA_TRANSP, LV_PART_MAIN);     //root背景透明
		lv_obj_set_style_border_width(root, 0, LV_PART_MAIN);           //root边框宽度为0
		lv_obj_set_style_pad_all(root, 0, LV_PART_MAIN);                //root内边距为0
		lv_obj_set_style_radius(root, 0, LV_PART_MAIN);                 //root圆角为0

		lv_obj_t * top = create_top_bar(root, &g_lbl_clock, NULL, g_group_home, NULL);  //创建顶部栏
		lv_obj_t * btn_runpause = add_encoder_top_btn(top, "启停", 100, g_group_home);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮
		lv_obj_add_event_cb(btn_runpause, cb_load_screen, LV_EVENT_CLICKED, g_scr_pay);
		add_encoder_top_btn(top, "电源", 180, g_group_home);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮

		//轮播区
		lv_obj_t * mid = lv_obj_create(root);       //轮播区，包含5个卡片
		lv_obj_set_size(mid, LV_PCT(100), LV_PCT(60));                  //轮播区大小
		lv_obj_set_pos(mid, 0, LV_PCT(10));                             //轮播区位置
		lv_obj_set_style_bg_opa(mid, LV_OPA_TRANSP, LV_PART_MAIN);          //轮播区背景透明
		lv_obj_set_style_border_width(mid, 0, LV_PART_MAIN);            //轮播区边框宽度为0
		lv_obj_set_style_pad_all(mid, 0, LV_PART_MAIN);                 //轮播区内边距为0
		lv_obj_set_style_radius(mid, 0, LV_PART_MAIN);                  //轮播区圆角为0
		lv_obj_add_flag(mid, LV_OBJ_FLAG_OVERFLOW_VISIBLE);             //允许轮播区内容超出边界显示
		lv_obj_set_style_layout(mid, LV_LAYOUT_NONE, LV_PART_MAIN);     //轮播区布局为无布局
		lv_obj_set_scroll_dir(mid, LV_DIR_NONE);                        //轮播区滚动方向为无滚动
		lv_obj_set_scrollbar_mode(mid, LV_SCROLLBAR_MODE_OFF);          //轮播区滚动条模式为无滚动条
		g_mode_carousel = mid;                                          //将轮播区赋值给全局变量 g_mode_carousel
		lv_obj_add_event_cb(mid, carousel_size_cb, LV_EVENT_SIZE_CHANGED, NULL); //当轮播区尺寸变化时，调用 carousel_size_cb 函数

		const uint32_t borders[] = { 0xFF8C9E, 0x6644AA, 0xFFFFFF, 0x44CCCC, 0xCC6644 };  //卡片边框颜色
		for(int i = 0; i < CAROUSEL_VISIBLE_SLOTS; i++) {
				lv_obj_t * card = lv_obj_create(mid);
				g_mode_cards[i] = card;
				lv_obj_set_size(card, s_mode_card_sz, s_mode_card_sz);                        //卡片大小
				lv_obj_set_style_radius(card, LV_RADIUS_CIRCLE, LV_PART_MAIN);                //卡片圆角为圆形
				lv_obj_set_style_bg_opa(card, LV_OPA_TRANSP, LV_PART_MAIN);                   //卡片背景透明
				lv_obj_set_style_border_width(card, 0, LV_PART_MAIN);                         //框的粗细
				lv_obj_set_style_border_color(card, lv_color_hex(borders[i % 5]), LV_PART_MAIN);  //框的颜色
				lv_obj_add_flag(card, LV_OBJ_FLAG_CLICKABLE);                                                   //接收指针/触摸事件
				lv_obj_add_event_cb(card, wheel_pointer_cb, LV_EVENT_PRESSED, NULL);                            //卡片按下事件
				lv_obj_add_event_cb(card, wheel_pointer_cb, LV_EVENT_PRESSING, NULL);                           //卡片拖动事件
				lv_obj_add_event_cb(card, wheel_pointer_cb, LV_EVENT_RELEASED, NULL);                           //卡片释放事件
				lv_obj_add_event_cb(card, mode_card_click, LV_EVENT_CLICKED, (void *)(uintptr_t)(unsigned)i);   //卡片点击事件
				if(i == CAROUSEL_CENTER_SLOT) {
					lv_obj_add_event_cb(card, mode_card_encoder_cb, LV_EVENT_FOCUSED, NULL);
					lv_obj_add_event_cb(card, mode_card_encoder_cb, LV_EVENT_DEFOCUSED, NULL);
					lv_obj_add_event_cb(card, mode_card_encoder_cb, LV_EVENT_KEY, NULL);
					ui_encoder_group_add_no_outline(g_group_home, card);
				}

				lv_obj_t * img = lv_image_create(card);
				g_mode_card_imgs[i] = img;
				lv_obj_center(img);

				// lv_obj_t * lab = lv_label_create(card);    //卡片标签
				// lv_label_set_text(lab, modes[i]);                                              //卡片标签文本
				// lv_obj_set_style_text_color(lab, lv_color_hex(COL_TEXT), LV_PART_MAIN);        //卡片标签颜色
				// lv_obj_align(lab, LV_ALIGN_CENTER, 0, 0);                                      //卡片标签居中
				// lv_obj_add_flag(lab, LV_OBJ_FLAG_EVENT_BUBBLE);                                //卡片标签事件冒泡
		}


		lv_obj_t * dots = lv_obj_create(root);        //指示条状态点区域，5 个程序各一点
		lv_obj_set_size(dots, LV_PCT(100), 30);     //指示条状态点区域大小
		lv_obj_set_pos(dots, 0, 402);               //dots位置                                     //指示条状态点区域位置
		lv_obj_set_style_bg_opa(dots, LV_OPA_TRANSP, LV_PART_MAIN);                        //指示条状态点区域背景透明
		lv_obj_set_style_border_width(dots, 0, LV_PART_MAIN);                              //指示条状态点区域边框宽度为0
		lv_obj_add_flag(dots, LV_OBJ_FLAG_OVERFLOW_VISIBLE);                               //指示条状态点区域内容超出边界显示
		lv_obj_set_style_layout(dots, LV_LAYOUT_NONE, LV_PART_MAIN);                       //指示条状态点区域布局为无布局
		lv_obj_set_scroll_dir(dots, LV_DIR_NONE);                                          //指示条状态点区域滚动方向为无滚动
		lv_obj_set_scrollbar_mode(dots, LV_SCROLLBAR_MODE_OFF);                            //指示条状态点区域滚动条模式为无滚动条
		for(int i = 0; i < TOTAL_PROGRAMS; i++) {
				lv_obj_t * d = lv_obj_create(dots);
				g_mode_dots[i] = d;
				lv_coord_t ds = (i == g_wheel_sel) ? 13 : 10;
				lv_obj_set_size(d, ds, ds);
				lv_obj_set_style_radius(d, LV_RADIUS_CIRCLE, LV_PART_MAIN);
				lv_obj_set_style_bg_color(d, lv_color_hex(i == g_wheel_sel ? COL_TEXT : COL_DIM), LV_PART_MAIN);
				lv_obj_set_style_bg_opa(d, LV_OPA_COVER, LV_PART_MAIN);
				lv_obj_set_style_border_width(d, 0, LV_PART_MAIN);
		}

		lv_obj_update_layout(root);//更新布局，调用 carousel_wrap_relayout 以正确放置轮播区卡片和指示点
		carousel_wrap_relayout();//轮播区布局

		lv_obj_t * cap = lv_label_create(root);  //副标题"自动感知 一键智洗"（在横线上方）
		lv_label_set_text(cap, "自动感知 一键智洗");
		lv_obj_set_style_text_color(cap, lv_color_hex(COL_DIM), LV_PART_MAIN);
		lv_obj_set_size(cap, LV_PCT(100), 30);                                 //副标题大小
		//lv_obj_set_pos(dots, 0, LV_PCT(75));                                    //副标题位置
		lv_obj_align(cap, LV_ALIGN_CENTER, 0, 185);                             //副标题位置：相对于中心向下偏移185
		g_cap_subtitle = cap;
		home_cap_update();  //商用洗无 AI 副标题

		lv_obj_t * bottom_panel = lv_obj_create(root);  //商用洗底部栏区域
		lv_obj_set_size(bottom_panel, LV_PCT(100), LV_PCT(25));
		lv_obj_set_pos(bottom_panel, 0, LV_PCT(75));
		lv_obj_set_style_bg_opa(bottom_panel, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(bottom_panel, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(bottom_panel, 0, LV_PART_MAIN);
		lv_obj_set_style_layout(bottom_panel, LV_LAYOUT_NONE, LV_PART_MAIN);



		const lv_coord_t bar_col1_x = (lv_coord_t)(UI_FIXED_W * 10 / 100 - UI_FIXED_W / 2);
		const lv_coord_t bar_col2_x = (lv_coord_t)(UI_FIXED_W * 30 / 100 - UI_FIXED_W / 2);
		const lv_coord_t bar_col3_x = (lv_coord_t)(UI_FIXED_W * 50 / 100 - UI_FIXED_W / 2);
		const lv_coord_t bar_col4_x = (lv_coord_t)(UI_FIXED_W * 70 / 100 - UI_FIXED_W / 2);
		const lv_coord_t bar_col5_x = (lv_coord_t)(UI_FIXED_W * 90 / 100 - UI_FIXED_W / 2);

		lv_obj_t * lbl_row = lv_obj_create(bottom_panel);   //文字标签行（横线上方）
		lv_obj_set_size(lbl_row, LV_PCT(100), 50);
		lv_obj_set_pos(lbl_row, 0, 0);
		lv_obj_set_style_bg_opa(lbl_row, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(lbl_row, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(lbl_row, 0, LV_PART_MAIN);
		lv_obj_set_style_layout(lbl_row, LV_LAYOUT_NONE, LV_PART_MAIN);

		lv_obj_t * lbl_time = lv_label_create(lbl_row);//程序时间
		g_lbl_home_time = lbl_time;
		lv_obj_set_style_text_color(lbl_time, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(lbl_time, s_font_sc_35);
		lv_obj_align(lbl_time, LV_ALIGN_CENTER, bar_col1_x, 0);

		lv_obj_t * lbl_temperature = lv_label_create(lbl_row);//洗涤温度
		g_lbl_home_temp = lbl_temperature;
		lv_obj_set_style_text_color(lbl_temperature, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(lbl_temperature, s_font_sc_35);
		lv_obj_align(lbl_temperature, LV_ALIGN_CENTER, bar_col2_x, 0);

		lv_obj_t * lbl_pay = lv_label_create(lbl_row);//程序金额
		g_lbl_home_pay = lbl_pay;
		lv_obj_set_style_text_color(lbl_pay, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(lbl_pay, s_font_sc_35);
		lv_obj_align(lbl_pay, LV_ALIGN_CENTER, bar_col3_x, 0);
		home_sync_program_labels();  //刷新主页程序标签

		lv_obj_t * lbl_language = lv_label_create(lbl_row);//语言
		lv_label_set_text(lbl_language, "China");
		lv_obj_set_style_text_color(lbl_language, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(lbl_language, s_font_sc_35);
		lv_obj_align(lbl_language, LV_ALIGN_CENTER, bar_col4_x, 0);

		lv_obj_t * lbl_manager = lv_label_create(lbl_row);//管理员登陆
		lv_label_set_text(lbl_manager, "Login");
		lv_obj_set_style_text_color(lbl_manager, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(lbl_manager, s_font_sc_35);
		lv_obj_align(lbl_manager, LV_ALIGN_CENTER, bar_col5_x, 0);

		const int sep_w_pct = 100;             /* 虚线宽度占 bottom_panel 百分比 */
		const lv_coord_t sep_stroke_w = 4;     /* 线粗 */
		const lv_coord_t sep_dash_len = 15;    /* 每段虚线长度 */
		const lv_coord_t sep_dash_gap = 15;    /* 段间空白长度 */
		const lv_coord_t sep_y = 60;           /* 相对 bottom_panel 顶部的 Y 偏移 */
		const lv_opa_t sep_opa = LV_OPA_COVER;
		const lv_coord_t sep_w = (lv_coord_t)(UI_FIXED_W * sep_w_pct / 100);
		static lv_point_precise_t sep_pts[2];

		sep_pts[0].x = 0;
		sep_pts[0].y = 0;
		sep_pts[1].x = sep_w;
		sep_pts[1].y = 0;

		lv_obj_t * sep_line = lv_line_create(bottom_panel);
		lv_obj_set_width(sep_line, sep_w);
		lv_obj_set_height(sep_line, sep_stroke_w + 4);
		lv_obj_align(sep_line, LV_ALIGN_TOP_MID, 0, sep_y);
		lv_obj_set_style_line_width(sep_line, sep_stroke_w, LV_PART_MAIN);
		lv_obj_set_style_line_dash_width(sep_line, sep_dash_len, LV_PART_MAIN);
		lv_obj_set_style_line_dash_gap(sep_line, sep_dash_gap, LV_PART_MAIN);
		lv_obj_set_style_line_color(sep_line, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		lv_obj_set_style_line_opa(sep_line, sep_opa, LV_PART_MAIN);
		lv_obj_set_style_line_rounded(sep_line, false, LV_PART_MAIN);
		lv_obj_set_style_bg_opa(sep_line, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(sep_line, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(sep_line, 0, LV_PART_MAIN);
		lv_obj_remove_flag(sep_line, LV_OBJ_FLAG_SCROLLABLE);
		lv_line_set_points_mutable(sep_line, sep_pts, 2);

		LV_IMAGE_DECLARE(comm_time);
		LV_IMAGE_DECLARE(temperature);
		LV_IMAGE_DECLARE(pay);
		LV_IMAGE_DECLARE(language);
		LV_IMAGE_DECLARE(manager);

		lv_obj_t * icon_row = lv_obj_create(bottom_panel);  //图标行（横线下方）
		lv_obj_set_size(icon_row, LV_PCT(100), LV_SIZE_CONTENT);
		lv_obj_set_pos(icon_row, 0, 85);
		lv_obj_set_style_bg_opa(icon_row, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(icon_row, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(icon_row, 0, LV_PART_MAIN);
		lv_obj_set_style_layout(icon_row, LV_LAYOUT_NONE, LV_PART_MAIN);

		lv_obj_t * img_time = lv_image_create(icon_row);
		lv_image_set_src(img_time, &comm_time);
		lv_obj_align(img_time, LV_ALIGN_TOP_MID, bar_col1_x, 0);

		lv_obj_t * img_temperature = lv_image_create(icon_row);
		lv_image_set_src(img_temperature, &temperature);
		lv_obj_align(img_temperature, LV_ALIGN_TOP_MID, bar_col2_x, 0);

		lv_obj_t * img_pay = lv_image_create(icon_row);
		lv_image_set_src(img_pay, &pay);
		lv_obj_align(img_pay, LV_ALIGN_TOP_MID, bar_col3_x, 0);

		lv_obj_t * img_language = lv_image_create(icon_row);
		lv_image_set_src(img_language, &language);
		lv_obj_align(img_language, LV_ALIGN_TOP_MID, bar_col4_x, 0);

		lv_obj_t * img_manager = lv_image_create(icon_row);
		lv_image_set_src(img_manager, &manager);
		lv_obj_align(img_manager, LV_ALIGN_TOP_MID, bar_col5_x, 0);
}








//获取指定程序索引的参数表项（时间/温度/价格）
static const ui_program_profile_t * program_profile_get(int32_t idx)  //获取指定程序索引的参数表项（时间/温度/价格）
{
	idx = wheel_mod_total(idx);  //程序索引取模
	return &g_program_profiles[(unsigned)idx];
}

//格式化为首页时间标签文本（如 35s）
static void program_format_time_label(uint32_t sec, char * buf, size_t buf_sz)  //格式化为首页时间标签文本（如 35s）
{
	snprintf(buf, buf_sz, "%us", (unsigned)sec);
}

//格式化为首页价格标签（¥N 或 --）
static void program_format_price_home(int32_t price, char * buf, size_t buf_sz)  //格式化为首页价格标签（¥N 或 --）
{
	if(price < 0) {
		snprintf(buf, buf_sz, "--");
	} else {
		snprintf(buf, buf_sz, "¥%d", price);
	}
}

//格式化为支付页价格标签（¥ N.00 或 --）
static void program_format_price_pay(int32_t price, char * buf, size_t buf_sz)  //格式化为支付页价格标签（¥ N.00 或 --）
{
	if(price < 0) {
		snprintf(buf, buf_sz, "--");
	} else {
		snprintf(buf, buf_sz, "¥ %d.00", price);
	}
}

//按当前选中程序刷新主页底部时间/温度/价格标签
static void home_sync_program_labels(void)  //刷新主页程序标签
{
	const ui_program_profile_t * profile = program_profile_get(g_wheel_sel);  //获取指定程序索引的参数表项（时间/温度/价格）
	char buf[16];

	if(g_lbl_home_time != NULL) {
		program_format_time_label(profile->wash_sec, buf, sizeof(buf));  //格式化为首页时间标签文本（如 35s）
		lv_label_set_text(g_lbl_home_time, buf);
	}
	if(g_lbl_home_temp != NULL) {
		lv_label_set_text(g_lbl_home_temp, profile->temp);
	}
	if(g_lbl_home_pay != NULL) {
		program_format_price_home(profile->price, buf, sizeof(buf));  //格式化为首页价格标签（¥N 或 --）
		lv_label_set_text(g_lbl_home_pay, buf);
	}
}

//按当前选中程序刷新支付页金额标签
static void pay_sync_price_label(void)  //刷新支付页金额
{
	if(g_lbl_pay_price == NULL) return;
	const ui_program_profile_t * profile = program_profile_get(g_wheel_sel);  //获取指定程序索引的参数表项（时间/温度/价格）
	char buf[16];
	program_format_price_pay(profile->price, buf, sizeof(buf));  //格式化为支付页价格标签（¥ N.00 或 --）
	lv_label_set_text(g_lbl_pay_price, buf);
}

//运行页程序名标签与 g_wheel_sel 保持一致
static void running_screen_sync_mode_name(void)  //运行页程序名标签与 g_wheel_sel 保持一致
{
	if(g_running_mode_label == NULL) return;
	int32_t idx = wheel_mod_total(g_wheel_sel);  //程序索引取模
	lv_label_set_text(g_running_mode_label, g_mode_display_names[(unsigned)idx]);
	lv_obj_invalidate(g_running_mode_label);
}

//将剩余秒数格式化为 M:SS
static void running_countdown_format(uint32_t sec, char * buf, size_t buf_sz)  //将剩余秒数格式化为 M:SS
{
	uint32_t min = sec / 60u;
	uint32_t s = sec % 60u;
	snprintf(buf, buf_sz, "%u:%02u", (unsigned)min, (unsigned)s);
}

//刷新运行页倒计时标签显示
static void running_countdown_update_label(void)  //更新倒计时标签
{
	if(g_running_time_label == NULL) return;
	char buf[12];
	running_countdown_format(g_running_remain_sec, buf, sizeof(buf));  //将剩余秒数格式化为 M:SS
	lv_label_set_text(g_running_time_label, buf);
}

//停止支付完成页 2 秒自动跳转定时器
static void pay_done_timer_stop(void)  //停止支付完成页 2 秒自动跳转定时器
{
	if(g_pay_done_timer != NULL) {
		lv_timer_delete(g_pay_done_timer);
		g_pay_done_timer = NULL;
	}
}

//支付完成页定时器回调：2 秒后进入运行页
static void cb_pay_done_timer(lv_timer_t * t)  //支付完成页定时器回调
{
	(void)t;
	pay_done_timer_stop();  //停止支付完成页 2 秒自动跳转定时器
	ui_screen_load(g_scr_running);  //加载目标屏幕
}

//启动支付完成页 2 秒自动跳转定时器
static void pay_done_timer_start(void)  //启动支付完成页 2 秒自动跳转定时器
{
	pay_done_timer_stop();  //停止支付完成页 2 秒自动跳转定时器
	g_pay_done_timer = lv_timer_create(cb_pay_done_timer, 2000, NULL);
	lv_timer_set_repeat_count(g_pay_done_timer, 1);
}

//停止暂停时倒计时闪烁定时器并恢复标签可见
static void running_blink_stop(void)  //停止暂停时倒计时闪烁定时器并恢复标签可见
{
	if(g_running_blink_timer != NULL) {
		lv_timer_delete(g_running_blink_timer);
		g_running_blink_timer = NULL;
	}
	g_running_blink_visible = true;
	if(g_running_time_label != NULL) {
		lv_obj_set_style_opa(g_running_time_label, LV_OPA_COVER, LV_PART_MAIN);
	}
}

//暂停时倒计时标签 500ms 闪烁定时器回调
static void cb_running_blink(lv_timer_t * t)  //暂停时倒计时标签 500ms 闪烁定时器回调
{
	(void)t;
	if(g_running_time_label == NULL) return;

	g_running_blink_visible = !g_running_blink_visible;
	lv_obj_set_style_opa(g_running_time_label,
		g_running_blink_visible ? LV_OPA_COVER : LV_OPA_TRANSP, LV_PART_MAIN);
}

//停止运行页倒计时定时器
static void running_countdown_stop(void)  //停止运行页倒计时定时器
{
	if(g_running_countdown_timer != NULL) {
		lv_timer_delete(g_running_countdown_timer);
		g_running_countdown_timer = NULL;
	}
}

//重置倒计时状态：清除暂停、闪烁与定时器
static void running_countdown_reset_all(void)  //重置倒计时状态
{
	g_running_countdown_paused = false;
	running_blink_stop();  //停止暂停时倒计时闪烁定时器并恢复标签可见
	running_countdown_stop();  //停止运行页倒计时定时器
}

//暂停倒计时并启动时间标签闪烁
static void running_countdown_pause(void)  //暂停倒计时并启动时间标签闪烁
{
	if(g_running_countdown_paused) return;
	if(g_running_countdown_timer == NULL) return;

	g_running_countdown_paused = true;
	running_countdown_stop();  //停止运行页倒计时定时器
	running_blink_stop();  //停止暂停时倒计时闪烁定时器并恢复标签可见
	g_running_blink_visible = true;
	if(g_running_time_label != NULL) {
		lv_obj_set_style_opa(g_running_time_label, LV_OPA_COVER, LV_PART_MAIN);
	}
	g_running_blink_timer = lv_timer_create(cb_running_blink, 500, NULL);
}

//恢复倒计时并停止闪烁
static void running_countdown_resume(void)  //恢复倒计时并停止闪烁
{
	if(!g_running_countdown_paused) return;

	g_running_countdown_paused = false;
	running_blink_stop();  //停止暂停时倒计时闪烁定时器并恢复标签可见
	running_countdown_arm();  //启动倒计时定时器
}

//运行页启停按钮：暂停/恢复倒计时
static void cb_running_runpause(lv_event_t * e)  //运行页启停按钮
{
	if(lv_event_get_code(e) != LV_EVENT_CLICKED) return;
	if(g_ui_child_lock) return;
	if(lv_scr_act() != g_scr_running) return;

	if(g_running_countdown_paused) {
		running_countdown_resume();  //恢复倒计时并停止闪烁
	} else {
		running_countdown_pause();  //暂停倒计时并启动时间标签闪烁
	}
}

//运行页每秒倒计时回调，归零后跳转结束页
static void cb_running_countdown(lv_timer_t * t)  //运行页每秒倒计时回调
{
	(void)t;
	if(g_running_remain_sec == 0u) return;

	g_running_remain_sec--;
	running_countdown_update_label();  //更新倒计时标签

	if(g_running_remain_sec == 0u) {
		running_countdown_reset_all();  //重置倒计时状态
		ui_send_beep_seq(7);  //发送结束蜂鸣
		ui_screen_load(g_scr_end);  //加载目标屏幕
	}
}

//若剩余时间>0 则启动 1 秒倒计时定时器
static void running_countdown_arm(void)  //启动倒计时定时器
{
	if(g_running_countdown_timer != NULL) return;
	if(g_running_remain_sec == 0u) return;
	g_running_countdown_timer = lv_timer_create(cb_running_countdown, 1000, NULL);
}

//进入运行页时按程序时长初始化并开始倒计时
static void running_countdown_start(void)  //初始化并开始倒计时
{
	const ui_program_profile_t * profile = program_profile_get(g_wheel_sel);  //获取指定程序索引的参数表项（时间/温度/价格）

	running_countdown_reset_all();  //重置倒计时状态
	g_running_remain_sec = profile->wash_sec;
	if(g_running_remain_sec == 0u) {
		g_running_remain_sec = 1u;
	}
	running_countdown_update_label();  //更新倒计时标签
	running_countdown_arm();  //启动倒计时定时器
}

//快洗运行页：点击运行后显示底部状态文字
static void cb_kuaixi_running_start(lv_event_t * e)  //快洗运行页
{
	(void)e;
	if(g_kuaixi_run_lbl_status != NULL) {
		lv_obj_clear_flag(g_kuaixi_run_lbl_status, LV_OBJ_FLAG_HIDDEN);
	}
	if(g_kuaixi_run_lbl_stages != NULL) {
		lv_obj_clear_flag(g_kuaixi_run_lbl_stages, LV_OBJ_FLAG_HIDDEN);
	}
}

//快洗运行页：点击添衣后隐藏底部状态文字
static void cb_kuaixi_running_add(lv_event_t * e)  //快洗运行页
{
	(void)e;
	if(g_kuaixi_run_lbl_status != NULL) {
		lv_obj_add_flag(g_kuaixi_run_lbl_status, LV_OBJ_FLAG_HIDDEN);
	}
	if(g_kuaixi_run_lbl_stages != NULL) {
		lv_obj_add_flag(g_kuaixi_run_lbl_stages, LV_OBJ_FLAG_HIDDEN);
	}
}
static void build_running(void)   //创建运行页面
{
		lv_obj_t * root = lv_obj_create(g_scr_running);
		lv_obj_set_size(root, LV_PCT(100), LV_PCT(100));
		lv_obj_set_pos(root, 0, 0);
		lv_obj_set_style_bg_opa(root, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(root, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(root, 0, LV_PART_MAIN);
		lv_obj_set_style_radius(root, 0, LV_PART_MAIN);
		lv_obj_set_style_layout(root, LV_LAYOUT_NONE, LV_PART_MAIN);

		LV_IMAGE_DECLARE(yunxingbackground);//运行界面背景图片
		lv_obj_t * bg = lv_image_create(root);
		lv_image_set_src(bg, &yunxingbackground);
		lv_obj_set_size(bg, (lv_coord_t)UI_FIXED_W, (lv_coord_t)UI_FIXED_H);
		lv_obj_align(bg, LV_ALIGN_CENTER, 0, 0);
		lv_image_set_inner_align(bg, LV_IMAGE_ALIGN_STRETCH);
		lv_obj_move_background(bg);

		lv_obj_t * top = create_top_bar(root, &g_lbl_clock_running, g_scr_home, g_group_running,  //创建顶部栏
			&g_running_btn_back);
		g_running_btn_runpause = add_encoder_top_btn(top, "启停", 100, g_group_running);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮
		lv_obj_add_event_cb(g_running_btn_runpause, cb_running_runpause, LV_EVENT_CLICKED, NULL);
		g_running_btn_power = add_encoder_top_btn(top, "电源", 180, g_group_running);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮

		lv_obj_t * mid = lv_obj_create(root);//中间栏
		lv_obj_set_size(mid, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
		lv_obj_align(mid, LV_ALIGN_CENTER, 0, -40);
		lv_obj_set_style_bg_opa(mid, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(mid, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(mid, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_column(mid, 24, LV_PART_MAIN);
		lv_obj_set_flex_flow(mid, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(mid, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
		g_running_mid = mid;

		lv_obj_t * mode_txt = lv_label_create(mid);
		g_running_mode_label = mode_txt;
		ui_set_obj_font(mode_txt, s_font_sc_50);
		lv_obj_set_style_text_color(mode_txt, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		running_screen_sync_mode_name();  //运行页程序名标签与 g_wheel_sel 保持一致

		lv_obj_t * time_txt = lv_label_create(mid);
		g_running_time_label = time_txt;
		lv_label_set_text(time_txt, "0:24");
		lv_obj_set_style_text_color(time_txt, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(time_txt, s_font_sc_125);

		lv_obj_t * child_lock = lv_button_create(root);
		g_running_child_lock_btn = child_lock;
		lv_obj_set_size(child_lock, 52, 52);
		lv_obj_set_style_radius(child_lock, LV_RADIUS_CIRCLE, LV_PART_MAIN);
		lv_obj_set_style_pad_all(child_lock, 0, LV_PART_MAIN);
		lv_obj_set_style_shadow_width(child_lock, 0, LV_PART_MAIN);
		lv_obj_set_style_bg_opa(child_lock, LV_OPA_COVER, LV_PART_MAIN);
		lv_obj_set_style_bg_color(child_lock, lv_color_hex(COL_CHILD_LOCK_WHITE), LV_PART_MAIN);
		lv_obj_set_style_border_width(child_lock, 2, LV_PART_MAIN);
		lv_obj_set_style_border_color(child_lock, lv_color_hex(0xBBBBBB), LV_PART_MAIN);
		lv_obj_remove_flag(child_lock, LV_OBJ_FLAG_SCROLLABLE);
		lv_obj_add_event_cb(child_lock, cb_running_child_lock_long, LV_EVENT_LONG_PRESSED, NULL);

		lv_obj_t * lock_lbl = lv_label_create(child_lock);
		g_running_child_lock_lbl = lock_lbl;
		lv_label_set_text(lock_lbl, "童锁");
		lv_label_set_long_mode(lock_lbl, LV_LABEL_LONG_CLIP);
		lv_obj_set_style_text_color(lock_lbl, lv_color_hex(0x222222), LV_PART_MAIN);
		lv_obj_set_style_text_align(lock_lbl, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
		ui_set_obj_font(lock_lbl, s_font_sc_20);
		lv_obj_center(lock_lbl);
		ui_encoder_group_add(g_group_running, child_lock);

		lv_obj_t * bot = lv_obj_create(root);
		lv_obj_set_size(bot, LV_PCT(100), LV_SIZE_CONTENT);
		lv_obj_align(bot, LV_ALIGN_BOTTOM_MID, 0, -60);//上移60
		lv_obj_set_style_bg_opa(bot, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(bot, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(bot, 0, LV_PART_MAIN);
		lv_obj_set_style_radius(bot, 0, LV_PART_MAIN);
		lv_obj_set_style_layout(bot, LV_LAYOUT_NONE, LV_PART_MAIN);

		lv_obj_t * st = lv_label_create(bot);
		lv_label_set_text(st, "洗涤中...");
		lv_obj_set_style_text_color(st, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(st, s_font_sc_35);
		lv_obj_align(st, LV_ALIGN_LEFT_MID, 60, 0);//右移60
		g_kuaixi_run_lbl_status = st;

		lv_obj_t * stages = lv_label_create(bot);
		lv_label_set_text(stages, "洗涤        漂洗        脱水");
		lv_obj_set_style_text_color(stages, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(stages, s_font_sc_35);
		lv_obj_align(stages, LV_ALIGN_RIGHT_MID, -60, 0);//左移60
		g_kuaixi_run_lbl_stages = stages;

		g_running_lock_blocker = lv_obj_create(root);
		lv_obj_set_size(g_running_lock_blocker, LV_PCT(100), LV_PCT(100));
		lv_obj_set_pos(g_running_lock_blocker, 0, 0);
		lv_obj_set_style_bg_opa(g_running_lock_blocker, LV_OPA_50, LV_PART_MAIN);
		lv_obj_set_style_bg_color(g_running_lock_blocker, lv_color_hex(0x000000), LV_PART_MAIN);
		lv_obj_set_style_border_width(g_running_lock_blocker, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(g_running_lock_blocker, 0, LV_PART_MAIN);
		lv_obj_remove_flag(g_running_lock_blocker, LV_OBJ_FLAG_SCROLLABLE);
		lv_obj_add_flag(g_running_lock_blocker, LV_OBJ_FLAG_CLICKABLE);
		lv_obj_add_flag(g_running_lock_blocker, LV_OBJ_FLAG_HIDDEN);

		running_child_lock_align_btn();  //将童锁按钮对齐到运行页中间栏右侧
		lv_obj_move_foreground(g_running_lock_blocker);
		lv_obj_move_foreground(g_running_child_lock_btn);
}

static void build_end(void)   //创建运行结束页面
{
		lv_obj_t * root = lv_obj_create(g_scr_end);
		lv_obj_set_size(root, LV_PCT(100), LV_PCT(100));
		lv_obj_set_pos(root, 0, 0);
		lv_obj_set_style_bg_opa(root, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(root, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(root, 0, LV_PART_MAIN);
		lv_obj_set_style_radius(root, 0, LV_PART_MAIN);
		lv_obj_set_style_layout(root, LV_LAYOUT_NONE, LV_PART_MAIN);

		lv_obj_t * top = create_top_bar(root, &g_lbl_clock_end, g_scr_home, g_group_end, NULL);  //创建顶部栏
		add_encoder_top_btn(top, "启停", 100, g_group_end);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮
		add_encoder_top_btn(top, "电源", 180, g_group_end);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮

		lv_obj_t * center = lv_obj_create(root);//中间栏
		lv_obj_set_size(center, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
		lv_obj_align(center, LV_ALIGN_CENTER, 0, 0);
		lv_obj_set_style_bg_opa(center, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(center, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(center, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_row(center, 16, LV_PART_MAIN);
		lv_obj_set_flex_flow(center, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_flex_align(center, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

		LV_IMAGE_DECLARE(end);
		lv_obj_t * img_end = lv_image_create(center);
		lv_image_set_src(img_end, &end);

		lv_obj_t * lbl_done = lv_label_create(center);
		lv_label_set_text(lbl_done, "洗涤完成");
		lv_obj_set_style_text_color(lbl_done, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(lbl_done, s_font_sc_50);

		lv_obj_t * lbl_hint = lv_label_create(center);
		lv_label_set_text(lbl_hint, "请及时取衣");
		lv_obj_set_style_text_color(lbl_hint, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(lbl_hint, s_font_sc_50);
}

static void build_pay(void)   //创建支付页面
{
		lv_obj_t * root = lv_obj_create(g_scr_pay);
		lv_obj_set_size(root, LV_PCT(100), LV_PCT(100));
		lv_obj_set_pos(root, 0, 0);
		lv_obj_set_style_bg_opa(root, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(root, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(root, 0, LV_PART_MAIN);
		lv_obj_set_style_radius(root, 0, LV_PART_MAIN);
		lv_obj_set_style_layout(root, LV_LAYOUT_NONE, LV_PART_MAIN);

		lv_obj_t * top = create_top_bar(root, &g_lbl_clock_pay, g_scr_home, g_group_pay, NULL);  //创建顶部栏
		lv_obj_t * btn_runpause = add_encoder_top_btn(top, "启停", 100, g_group_pay);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮
		lv_obj_add_event_cb(btn_runpause, cb_load_screen, LV_EVENT_CLICKED, g_scr_pay_done);
		add_encoder_top_btn(top, "电源", 180, g_group_pay);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮

		lv_obj_t * center = lv_obj_create(root);
		lv_obj_set_size(center, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
		lv_obj_align(center, LV_ALIGN_CENTER, 0, 0);
		lv_obj_set_style_bg_opa(center, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(center, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(center, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_row(center, 20, LV_PART_MAIN);
		lv_obj_set_flex_flow(center, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_flex_align(center, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

		LV_IMAGE_DECLARE(QR_code);
		lv_obj_t * img_qr = lv_image_create(center);
		lv_image_set_src(img_qr, &QR_code);

		lv_obj_t * lbl_price = lv_label_create(center);
		g_lbl_pay_price = lbl_price;
		lv_obj_set_style_text_color(lbl_price, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(lbl_price, s_font_sc_35);

		lv_obj_t * lbl_hint = lv_label_create(center);
		lv_label_set_text(lbl_hint, "请扫描屏幕上二维码\n支付完成机器自动运行");
		lv_obj_set_style_text_color(lbl_hint, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		lv_label_set_long_mode(lbl_hint, LV_LABEL_LONG_WRAP);
		lv_obj_set_width(lbl_hint, 560);
		lv_obj_set_style_text_align(lbl_hint, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN);
		ui_set_obj_font(lbl_hint, s_font_sc_30);
		pay_sync_price_label();  //刷新支付页金额
}

static void build_pay_done(void)   //创建支付完成页面
{
		lv_obj_t * root = lv_obj_create(g_scr_pay_done);
		lv_obj_set_size(root, LV_PCT(100), LV_PCT(100));
		lv_obj_set_pos(root, 0, 0);
		lv_obj_set_style_bg_opa(root, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(root, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(root, 0, LV_PART_MAIN);
		lv_obj_set_style_radius(root, 0, LV_PART_MAIN);
		lv_obj_set_style_layout(root, LV_LAYOUT_NONE, LV_PART_MAIN);

		lv_obj_t * top = create_top_bar(root, &g_lbl_clock_pay_done, g_scr_home, g_group_pay_done, NULL);  //创建顶部栏
		add_encoder_top_btn(top, "启停", 100, g_group_pay_done);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮
		add_encoder_top_btn(top, "电源", 180, g_group_pay_done);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮

		lv_obj_t * center = lv_obj_create(root);
		lv_obj_set_size(center, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
		lv_obj_align(center, LV_ALIGN_CENTER, 0, 0);
		lv_obj_set_style_bg_opa(center, LV_OPA_TRANSP, LV_PART_MAIN);
		lv_obj_set_style_border_width(center, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_all(center, 0, LV_PART_MAIN);
		lv_obj_set_style_pad_row(center, 16, LV_PART_MAIN);
		lv_obj_set_flex_flow(center, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_flex_align(center, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

		LV_IMAGE_DECLARE(end);
		lv_obj_t * img_done = lv_image_create(center);
		lv_image_set_src(img_done, &end);

		lv_obj_t * lbl_done = lv_label_create(center);
		lv_label_set_text(lbl_done, "支付完成");
		lv_obj_set_style_text_color(lbl_done, lv_color_hex(COL_TEXT), LV_PART_MAIN);
		ui_set_obj_font(lbl_done, s_font_sc_50);
}




//构建关机/待机页：仅顶部栏与启停/电源
static void build_off()  //构建关机/待机页
{
		lv_obj_t * row = lv_obj_create(g_scr_off);
		lv_obj_set_size(row, LV_PCT(100), LV_PCT(100));                //row大小
		lv_obj_set_pos(row, 0, 0);                                     //row位置
		lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, LV_PART_MAIN);     //row背景透明
		lv_obj_set_style_border_width(row, 0, LV_PART_MAIN);           //row边框宽度为0
		lv_obj_set_style_pad_all(row, 0, LV_PART_MAIN);                //row内边距为0
		lv_obj_set_style_radius(row, 0, LV_PART_MAIN);                 //row圆角为0

		lv_obj_t * top = create_top_bar(row, &g_lbl_clock_off, NULL, g_group_off, NULL);  //创建顶部栏
		add_encoder_top_btn(top, "启停", 100, g_group_off);  //在顶部栏添加编码器可聚焦的启停/电源类文本按钮
		g_off_btn_power = add_encoder_top_btn(top, "电源", 180, g_group_off);  //待机页电源键：长按 3 秒唤醒
		lv_obj_add_event_cb(g_off_btn_power, cb_off_power_long, LV_EVENT_LONG_PRESSED, NULL);
}








//UI 入口：字体、屏幕、编码器 group、各页面构建并加载主页
void ui_init(void)  //UI 入口
{
		if(g_ui_group == NULL) {
			g_ui_group = lv_group_create();
			lv_group_set_wrap(g_ui_group, false);//开启 “循环聚焦”
		}
		lv_group_set_default(g_ui_group);
		{
			lv_indev_t * indev = NULL;
			while((indev = lv_indev_get_next(indev)) != NULL) {
				lv_indev_type_t type = lv_indev_get_type(indev);
				if(type == LV_INDEV_TYPE_ENCODER || type == LV_INDEV_TYPE_KEYPAD) {
					lv_indev_set_group(indev, g_ui_group);
				}
			}
		}

		ui_layout_init();                   //界面布局参数初始化
		ui_apply_chinese_font();            //先设置主题字体，确保后续创建的控件可显示中文
		create_screens();                   //创建界面，并按当前显示分辨率设满屏宽高
		ui_apply_indev_long_press_ms(CHILD_LOCK_LONG_PRESS_MS);  //统一设置指针/编码器长按判定时间

		g_group_off = lv_group_create();
		g_group_home = lv_group_create();
		g_group_running = lv_group_create();
		g_group_end = lv_group_create();
		g_group_pay = lv_group_create();
		g_group_pay_done = lv_group_create();
		lv_group_set_wrap(g_group_off, false);
		lv_group_set_wrap(g_group_home, false);
		lv_group_set_wrap(g_group_running, false);
		lv_group_set_wrap(g_group_end, false);
		lv_group_set_wrap(g_group_pay, false);
		lv_group_set_wrap(g_group_pay_done, false);

		build_off();                        //构建关机/待机页
		build_home();                       //创建主页
		build_running();                    //创建程序运行界面
		build_end();                        //创建运行结束界面
		build_pay();                        //创建支付界面
		build_pay_done();                   //创建支付完成界面

		ui_idle_init();                     //空闲 3 分钟进待机；输入活动重置计时

		// 加载主页并切换编码器到主页 group
		ui_screen_load(g_scr_home);  //加载目标屏幕
		lv_obj_update_layout(g_scr_home);   //更新主页布局
}
